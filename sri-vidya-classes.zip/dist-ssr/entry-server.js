import { renderToString } from "react-dom/server";
import { Link, NavLink, Outlet, Route, Routes, StaticRouter, useLocation, useParams, useSearchParams } from "react-router-dom";
import { useEffect, useRef, useState, useSyncExternalStore } from "react";
import { ArrowLeft, ArrowRight, ArrowUp, ArrowUpRight, Atom, BookOpen, Check, ClipboardCheck, Clock, Compass, Copy, GraduationCap, Image, Layers, MapPin, Maximize2, Menu, MessageCircle, Phone, RotateCcw, Search, Sprout, Trophy, X } from "lucide-react";
import { Fragment, jsx, jsxs } from "react/jsx-runtime";
import gsap from "gsap";
// src/config/articles.ts
var articleCategories = [
	"Concept-based learning",
	"IIT-JEE preparation",
	"NEET preparation",
	"School foundation",
	"Study techniques",
	"Organic chemistry"
];
var articles = [
	{
		slug: "understand-before-you-memorise",
		category: "Concept-based learning",
		cover: "concept",
		title: "From remembering a formula to understanding an idea",
		summary: "Use explanation, examples and boundary checks to make a concept your own.",
		takeaway: "A useful explanation connects a rule, its meaning and the conditions where it applies.",
		sections: [
			{
				id: "meaning",
				title: "Begin with what the symbols mean",
				paragraphs: ["Before using a formula, name each quantity and its unit. Ask what relationship the expression describes. For speed = distance ÷ time, a fixed distance covered in less time means a larger speed. Units give another check: metres divided by seconds produces metres per second.", "Memorising an expression can be helpful, but it is only one part of learning. Work out when the expression applies and which details of a question matter."]
			},
			{
				id: "examples",
				title: "Change one thing at a time",
				paragraphs: ["Compare two journeys over 100 metres: one takes 20 seconds and the other 25 seconds. The average speeds are 5 m/s and 4 m/s. Now keep the time fixed and double the distance. Predict the change before calculating.", "This kind of comparison tests the relationship rather than your ability to substitute numbers. If your prediction is wrong, use the worked answer to find the missing connection."]
			},
			{
				id: "check",
				title: "Explain, then check",
				paragraphs: ["Close your notes and explain the idea in a few sentences. Include an example and a situation where a common shortcut would fail. Retrieval practice has supported meaningful learning in experimental research; it does not promise a particular exam score."],
				steps: [
					"State the rule in words.",
					"Solve a straightforward example without notes.",
					"Change one condition and predict the effect.",
					"Check your explanation against the textbook and correct it."
				]
			},
			{
				id: "limits",
				title: "Notice the limits of a shortcut",
				paragraphs: ["For a round trip, average speed is total distance divided by total time. Simply averaging the two speeds is not always correct. This is a useful reminder to return to definitions before choosing an operation."]
			}
		],
		practice: {
			title: "Try a round-trip check",
			task: "A student travels 60 km at 30 km/h and returns 60 km at 60 km/h. What is the average speed for the entire trip?",
			answer: "The two journeys take 2 hours and 1 hour. Total distance is 120 km and total time is 3 hours, giving 40 km/h. The arithmetic mean, 45 km/h, is not the trip’s average speed."
		},
		sources: [{
			title: "Karpicke & Blunt (2011): retrieval practice and meaningful learning",
			url: "https://pubmed.ncbi.nlm.nih.gov/21252317/"
		}],
		related: ["a-revision-loop-that-tests-understanding", "fractions-ratios-and-algebra-foundations"]
	},
	{
		slug: "jee-problem-solving-with-an-error-log",
		category: "IIT-JEE preparation",
		cover: "jee",
		title: "Build a JEE problem-solving routine with an error log",
		summary: "Turn an incorrect answer into a specific next step instead of another page of copied solutions.",
		takeaway: "Record why your first attempt failed, then test the correction on a fresh problem.",
		sections: [
			{
				id: "scope",
				title: "Separate syllabus planning from daily practice",
				paragraphs: ["Check the official syllabus and information bulletin for the exam and year you intend to take. JEE (Main) and JEE (Advanced) have separate official sources; do not assume one document describes both.", "For daily study, choose a narrow target such as setting up equations or interpreting a graph. A chapter name alone is often too broad to tell you what to practise next. These are study suggestions, not an official exam plan."]
			},
			{
				id: "attempt",
				title: "Make the first attempt visible",
				paragraphs: ["Write the known quantities, the unknown and a diagram where useful. State the principle you plan to use before calculating. If you get stuck, mark the exact step rather than replacing your work with the solution.", "After a genuine attempt, compare with a reliable worked solution. Ask whether the difficulty was conceptual, algebraic, an overlooked condition or a reading error."]
			},
			{
				id: "log",
				title: "Keep a small, usable error log",
				paragraphs: ["One sentence per error is often enough. “Used the correct equation but changed the sign of a negative term” is more useful than “careless mistake”."],
				steps: [
					"Record the topic and the point where your reasoning changed.",
					"Write a correction in your own words.",
					"Solve a similar but not identical question without the solution.",
					"Return later to check whether the correction holds."
				]
			},
			{
				id: "timing",
				title: "Add timing after you can explain the method",
				paragraphs: ["Use short timed sets to observe pacing, not to replace understanding. Review the questions you guessed or skipped as well as the ones you answered incorrectly. No single question count or timetable suits every student."]
			}
		],
		practice: {
			title: "Classify an algebra error",
			task: "A student solves 3(x − 2) = 12 as 3x − 2 = 12. What should the error log say, and what is the correct value of x?",
			answer: "The multiplier must apply to both terms: 3x − 6 = 12, so x = 6. Record “did not distribute 3 to the constant term”, then try another bracket-expansion problem."
		},
		sources: [{
			title: "Official JEE (Main) syllabus, bulletins and notices",
			url: "https://jeemain.nta.nic.in/"
		}, {
			title: "Official JEE (Advanced) information",
			url: "https://jeeadv.ac.in/"
		}],
		related: ["understand-before-you-memorise", "a-revision-loop-that-tests-understanding"]
	},
	{
		slug: "neet-revision-with-recall-and-checks",
		category: "NEET preparation",
		cover: "neet",
		title: "Make NEET revision a cycle of recall and correction",
		summary: "Connect factual recall, diagrams and numerical reasoning with a practical review routine.",
		takeaway: "A familiar page is not the same as an answer you can produce and explain without looking.",
		sections: [
			{
				id: "syllabus",
				title: "Start with the applicable syllabus",
				paragraphs: ["Use the official NEET portal to locate the syllabus and information bulletin for your intended exam year. Match your topic list to those documents before planning revision. This article gives general study methods, not predictions about questions or chapter weightage."]
			},
			{
				id: "recall",
				title: "Turn reading into a question",
				paragraphs: ["After a short passage, close the book and write two questions about it. Answer them before checking. For a diagram, redraw the essential structure and label it from memory, then compare carefully with the original.", "Keep the textbook nearby for correction. An unchecked memory error can become a repeated mistake. Record what was missing, rather than merely marking the page “revised”."]
			},
			{
				id: "reason",
				title: "Explain the reason behind an answer",
				paragraphs: ["For a multiple-choice practice question, explain why your chosen option fits the question. Where possible, identify what makes each alternative unsuitable. In numerical work, include units and a rough reasonableness check.", "Avoid assigning yourself confidence based only on recognition. A useful test is whether you can explain the same idea in a fresh example."]
			},
			{
				id: "review",
				title: "Review small gaps consistently",
				paragraphs: ["Group errors by cause: a forgotten fact, a confused relationship, a misread qualifier or an incorrect calculation. Choose the next practice task from that diagnosis."],
				steps: [
					"Recall before checking.",
					"Correct against a reliable source.",
					"Practise the weak point in a different question.",
					"Revisit it after a gap and check again."
				]
			}
		],
		practice: {
			title: "Check a concentration calculation",
			task: "A solution contains 0.20 mol of solute in a final solution volume of 0.50 L. What is its molar concentration?",
			answer: "Molar concentration is amount of solute divided by solution volume in litres: 0.20 ÷ 0.50 = 0.40 mol/L. Use the final solution volume, not just the volume of solvent added."
		},
		sources: [{
			title: "Official NEET syllabus, information and notices",
			url: "https://neet.nta.nic.in/"
		}],
		related: ["a-revision-loop-that-tests-understanding", "resonance-without-moving-atoms"]
	},
	{
		slug: "fractions-ratios-and-algebra-foundations",
		category: "School foundation",
		cover: "foundation",
		title: "Fractions, ratios and algebra: three connected foundations",
		summary: "See how equal parts and multiplicative comparisons support later mathematical reasoning.",
		takeaway: "Before applying a rule, identify the whole, the units and the relationship you are comparing.",
		sections: [
			{
				id: "fractions",
				title: "A fraction depends on its whole",
				paragraphs: ["Three quarters means three equal parts when a whole is divided into four equal parts. If the pieces are not equal, counting three of four pieces does not establish three quarters. Draw a strip or number line when the meaning feels uncertain.", "To add one half and one third of the same whole, express both using sixths: 3/6 + 2/6 = 5/6. Adding denominators would change the size of the parts without preserving their meaning."]
			},
			{
				id: "ratios",
				title: "A ratio compares quantities",
				paragraphs: ["A red-to-blue bead ratio of 2:3 describes two parts red for every three parts blue. There are five parts in total, so the red fraction of all beads is 2/5, not 2/3.", "State which quantities you compare. “Red to blue” and “red to all beads” are different questions even when the objects are the same."]
			},
			{
				id: "algebra",
				title: "An equation keeps two sides equal",
				paragraphs: ["In x + 7 = 19, subtracting 7 from both sides preserves equality and gives x = 12. Thinking about balance is more reliable than treating a term as something that simply “moves across”.", "Check a solution by substituting it back into the original equation. The check can reveal a sign error even when the later calculations look tidy."]
			},
			{
				id: "routine",
				title: "Use pictures before shortcuts",
				paragraphs: ["For a difficult question, draw equal parts, write the compared quantities and label what is unknown. Then translate the picture into arithmetic or an equation. Choose examples appropriate to the student’s class rather than rushing to an advanced procedure."]
			}
		],
		practice: {
			title: "Connect a ratio to a total",
			task: "A box contains red and blue beads in the ratio 2:3. There are 30 beads altogether. How many are red?",
			answer: "The total contains 2 + 3 = 5 equal parts. Each part is 30 ÷ 5 = 6 beads, so the red beads number 2 × 6 = 12. Check: 12 red and 18 blue gives the required 2:3 ratio."
		},
		sources: [],
		related: ["understand-before-you-memorise", "a-revision-loop-that-tests-understanding"]
	},
	{
		slug: "a-revision-loop-that-tests-understanding",
		category: "Study techniques",
		cover: "study",
		title: "A revision loop that tests understanding",
		summary: "Combine retrieval, feedback and spaced returns without creating an unmanageable timetable.",
		takeaway: "Try to recall, check accurately, and come back later. Adjust the gap to the difficulty of the material.",
		sections: [
			{
				id: "retrieve",
				title: "Retrieve before rereading",
				paragraphs: ["Choose a small topic. Without notes, answer a question, outline a process or solve a short problem. Then open the source and compare. Research on retrieval practice supports using this kind of active recall as a learning activity, rather than relying only on elaborative study.", "A blank page is useful feedback, not a verdict on ability. Identify the missing idea and rebuild it with a reliable explanation."]
			},
			{
				id: "feedback",
				title: "Make feedback specific",
				paragraphs: ["Separate what you knew from what you inferred or guessed. Write a brief correction that explains the reason. If a solution uses a step you cannot justify, ask for clarification before treating the question as complete.", "For example, write “converted minutes to seconds before using m/s” rather than “check units”. A specific correction can guide your next attempt."]
			},
			{
				id: "spacing",
				title: "Return after a gap",
				paragraphs: ["Research on distributed practice supports spreading learning over time. It does not prescribe one perfect spacing schedule for every learner or subject. A practical starting point is to revisit material after a day, later in the week and again after a longer gap, adjusting as needed.", "If recall is consistently easy, make the next attempt less familiar. If it fails repeatedly, shorten the gap and revisit the explanation. This is an adjustable routine, not a scientifically fixed timetable."]
			},
			{
				id: "manageable",
				title: "Keep the review list manageable",
				paragraphs: ["Choose a few priority gaps rather than copying every page into a revision system. Include enough rest and realistic time for schoolwork. A useful review list tells you what to attempt next and what evidence would show improvement."]
			}
		],
		practice: {
			title: "Try a retrieval card",
			task: "Write a question on one side of a card and a checked answer on the other. Attempt the answer before turning the card over. What should you record if you partly remember it?",
			answer: "Record the part you recalled correctly and the specific part you missed. Correct it against the source, then schedule another attempt. Reading the answer first would not test retrieval."
		},
		sources: [{
			title: "Karpicke & Blunt (2011): retrieval practice",
			url: "https://pubmed.ncbi.nlm.nih.gov/21252317/"
		}, {
			title: "Cepeda et al. (2006): distributed practice review",
			url: "https://doi.org/10.1037/0033-2909.132.3.354"
		}],
		related: ["jee-problem-solving-with-an-error-log", "neet-revision-with-recall-and-checks"]
	},
	{
		slug: "resonance-without-moving-atoms",
		category: "Organic chemistry",
		cover: "chemistry",
		title: "Resonance: different drawings, the same atom framework",
		summary: "A short guide to recognising valid resonance contributors and avoiding a common misconception.",
		takeaway: "Resonance contributors represent one species; they are not separate molecules rapidly switching places.",
		sections: [
			{
				id: "model",
				title: "What resonance drawings represent",
				paragraphs: ["Some electron distributions need more than one Lewis structure to represent them. The actual species is a resonance hybrid. Contributors are drawings used to describe it, not separate forms in equilibrium."]
			},
			{
				id: "electrons",
				title: "Keep atoms fixed; track electron pairs",
				paragraphs: ["Valid contributors keep the same atom connectivity and total charge. They differ in the placement of π electrons or lone pairs. A full curved arrow starts at an electron pair and points to where that pair is represented in the next drawing.", "For the acetate ion, one oxygen is drawn with a double bond and the other with a negative charge in each of two equivalent contributors. The hybrid describes delocalisation across the group."]
			},
			{
				id: "checks",
				title: "Check charge and valence",
				paragraphs: ["After drawing a contributor, recount formal charges and check valence. A carbon with five ordinary bonds is not an acceptable second-row Lewis structure. Moving a hydrogen to a new atom changes the framework and is not a resonance operation."],
				steps: [
					"Label the atom framework before drawing arrows.",
					"Identify the starting electron pair.",
					"Draw the resulting bonds and lone pairs.",
					"Check total charge and second-row octets."
				]
			},
			{
				id: "language",
				title: "Use precise language",
				paragraphs: ["Say “these drawings contribute to the resonance description”, rather than saying the molecule flips between them. Keep this distinction separate from a reaction or proton transfer."]
			}
		],
		practice: {
			title: "A quick validity test",
			task: "Two drawings have the same overall charge, but a hydrogen is attached to a different oxygen. Is equal charge enough to make them resonance contributors?",
			answer: "No. A resonance operation preserves the atom framework. Moving a hydrogen to another atom changes that framework; the pair is not justified as resonance contributors merely by having the same total charge."
		},
		sources: [{
			title: "OpenStax Organic Chemistry: resonance",
			url: "https://openstax.org/books/organic-chemistry/pages/2-4-resonance"
		}, {
			title: "OpenStax Organic Chemistry: rules for resonance forms",
			url: "https://openstax.org/books/organic-chemistry/pages/2-5-rules-for-resonance-forms"
		}],
		related: ["understand-before-you-memorise", "neet-revision-with-recall-and-checks"]
	}
];
function readingMinutes(article) {
	const words = [
		article.summary,
		article.takeaway,
		...article.sections.flatMap((section) => [
			section.title,
			...section.paragraphs,
			...section.steps ?? []
		]),
		article.practice.task,
		article.practice.answer
	].join(" ").split(/\s+/).length;
	return Math.max(1, Math.ceil(words / 180));
}
// src/components/ui.tsx
function Button({ to, children, secondary = false }) {
	return /* @__PURE__ */ jsx(Link, {
		className: `button ${secondary ? "button-secondary" : ""}`,
		to,
		children
	});
}
function Card({ children, className = "" }) {
	return /* @__PURE__ */ jsx("div", {
		className: `card ${className}`,
		children
	});
}
function SectionHeading({ eyebrow, title, children }) {
	return /* @__PURE__ */ jsxs("div", {
		className: "section-heading",
		children: [
			/* @__PURE__ */ jsx("span", {
				className: "eyebrow",
				children: eyebrow
			}),
			/* @__PURE__ */ jsx("h2", { children: title }),
			children && /* @__PURE__ */ jsx("p", { children })
		]
	});
}
function ResponsiveImage({ alt, ...props }) {
	return /* @__PURE__ */ jsx("img", {
		loading: "lazy",
		decoding: "async",
		...props,
		alt,
		className: `responsive-image ${props.className ?? ""}`
	});
}
function Motion({ children, className = "" }) {
	return /* @__PURE__ */ jsx("div", {
		className: `motion ${className}`,
		children
	});
}
// src/config/pages.ts
var pageInfo = { "/terms": ["Terms", "Information about using this website."] };
// src/pages/ContentPage.tsx
function ContentPage() {
	const { pathname } = useLocation();
	const [title, description] = pageInfo[pathname];
	return /* @__PURE__ */ jsx("section", {
		className: "section page-section",
		children: /* @__PURE__ */ jsxs("div", {
			className: "container",
			children: [
				/* @__PURE__ */ jsx("nav", {
					className: "academic-breadcrumb",
					"aria-label": "Breadcrumb",
					children: /* @__PURE__ */ jsxs("ol", { children: [/* @__PURE__ */ jsx("li", { children: /* @__PURE__ */ jsx(Link, {
						to: "/",
						children: "Home"
					}) }), /* @__PURE__ */ jsx("li", {
						"aria-current": "page",
						children: title
					})] })
				}),
				/* @__PURE__ */ jsxs("div", {
					className: "section-heading",
					children: [
						/* @__PURE__ */ jsx("span", {
							className: "eyebrow",
							children: "SRI VIDYA CLASSES"
						}),
						/* @__PURE__ */ jsx("h1", { children: title }),
						/* @__PURE__ */ jsx("p", { children: description })
					]
				}),
				/* @__PURE__ */ jsxs(Card, { children: [/* @__PURE__ */ jsx("h2", { children: "Website information" }), /* @__PURE__ */ jsx("p", { children: "Program, admission and other institute information will be published after approval. Visiting this website does not constitute an admission application or confirmation. Full terms are awaiting approval." })] })
			]
		})
	});
}
function NotFound() {
	return /* @__PURE__ */ jsx("section", {
		className: "section page-section",
		children: /* @__PURE__ */ jsxs("div", {
			className: "container",
			children: [
				/* @__PURE__ */ jsxs("div", {
					className: "section-heading",
					children: [
						/* @__PURE__ */ jsx("span", {
							className: "eyebrow",
							children: "404 · PAGE NOT FOUND"
						}),
						/* @__PURE__ */ jsx("h1", { children: "Let’s get you back on track." }),
						/* @__PURE__ */ jsx("p", { children: "This page is unavailable. Explore Sri Vidya Classes from the homepage." })
					]
				}),
				/* @__PURE__ */ jsx(Button, {
					to: "/",
					children: "Back to home"
				}),
				/* @__PURE__ */ jsxs("div", {
					className: "actions",
					children: [/* @__PURE__ */ jsx(Link, {
						className: "text-link",
						to: "/programs",
						children: "Explore programs"
					}), /* @__PURE__ */ jsx(Link, {
						className: "text-link",
						to: "/contact",
						children: "Contact the institute"
					})]
				})
			]
		})
	});
}
// src/hooks/useHomepageReveals.ts
function useHomepageReveals() {
	const root = useRef(null);
	useEffect(() => {
		const media = gsap.matchMedia();
		media.add("(prefers-reduced-motion: no-preference)", () => {
			const observers = [];
			const context = gsap.context(() => {
				root.current?.querySelectorAll("[data-reveal-group]").forEach((group) => {
					const targets = group.querySelectorAll("[data-reveal]");
					const observer = new IntersectionObserver((entries) => {
						if (!entries.some((entry) => entry.isIntersecting)) return;
						context.add(() => {
							gsap.fromTo(targets, {
								y: 20,
								opacity: 0
							}, {
								y: 0,
								opacity: 1,
								duration: .65,
								stagger: .09,
								ease: "power2.out",
								clearProps: "all"
							});
						});
						observer.disconnect();
					}, { threshold: .12 });
					observer.observe(group);
					observers.push(observer);
				});
			}, root);
			return () => {
				observers.forEach((observer) => observer.disconnect());
				context.revert();
			};
		});
		return () => media.revert();
	}, []);
	return root;
}
// src/pages/LearningPages.tsx
var subscribeHydration = () => () => {};
function ArticleCover({ article, large = false }) {
	return /* @__PURE__ */ jsxs("div", {
		className: `article-cover cover-${article.cover} ${large ? "cover-large" : ""}`,
		"aria-hidden": "true",
		children: [
			/* @__PURE__ */ jsxs("svg", {
				viewBox: "0 0 600 340",
				fill: "none",
				preserveAspectRatio: "xMidYMid slice",
				children: [
					/* @__PURE__ */ jsx("defs", { children: /* @__PURE__ */ jsx("pattern", {
						id: `grid-${article.slug}-${large ? "large" : "small"}`,
						width: "30",
						height: "30",
						patternUnits: "userSpaceOnUse",
						children: /* @__PURE__ */ jsx("path", {
							d: "M30 0H0V30",
							stroke: "currentColor",
							opacity: ".07"
						})
					}) }),
					/* @__PURE__ */ jsx("rect", {
						width: "600",
						height: "340",
						fill: `url(#grid-${article.slug}-${large ? "large" : "small"})`
					}),
					/* @__PURE__ */ jsx("circle", {
						cx: "440",
						cy: "175",
						r: "120",
						stroke: "currentColor",
						opacity: ".16"
					}),
					/* @__PURE__ */ jsx("circle", {
						cx: "440",
						cy: "175",
						r: "90",
						stroke: "currentColor",
						opacity: ".16"
					}),
					article.cover === "chemistry" ? /* @__PURE__ */ jsx("path", {
						d: "M370 115l52-30 52 30v60l-52 30-52-30zm104 0 52-30 52 30v60l-52 30-52-30",
						stroke: "currentColor",
						strokeWidth: "2",
						opacity: ".5"
					}) : article.cover === "neet" ? /* @__PURE__ */ jsx("path", {
						d: "M380 60c150 50-30 170 120 220m0-220c-150 50 30 170-120 220m10-200h100m-95 30h90m-60 30h30m-30 30h30m-60 30h90m-95 30h100m-95 30h90",
						stroke: "currentColor",
						strokeWidth: "2",
						opacity: ".5"
					}) : article.cover === "foundation" ? /* @__PURE__ */ jsx("path", {
						d: "M350 225h190M350 200v50m63-50v50m63-50v50m64-50v50M350 125h190",
						stroke: "currentColor",
						strokeWidth: "2",
						opacity: ".5"
					}) : /* @__PURE__ */ jsx("path", {
						d: "M340 225l55-90 60 40 80-85M340 80v170h210",
						stroke: "currentColor",
						strokeWidth: "2",
						opacity: ".4"
					})
				]
			}),
			/* @__PURE__ */ jsx("span", {
				className: "cover-edition",
				children: "SRI VIDYA · LEARNING NOTES"
			}),
			/* @__PURE__ */ jsx("strong", { children: {
				concept: "WHY?",
				jee: "x² + y²",
				neet: "DNA",
				foundation: "½ + ⅓",
				study: "RECALL",
				chemistry: "π ↔ π"
			}[article.cover] }),
			/* @__PURE__ */ jsx("span", {
				className: "cover-topic",
				children: article.category
			})
		]
	});
}
function ArticleCard({ article }) {
	return /* @__PURE__ */ jsxs("article", {
		className: "learning-card",
		"data-reveal": true,
		children: [/* @__PURE__ */ jsx(Link, {
			to: `/learning-hub/${article.slug}`,
			"aria-label": `Read: ${article.title}`,
			children: /* @__PURE__ */ jsx(ArticleCover, { article })
		}), /* @__PURE__ */ jsxs("div", {
			className: "learning-card-body",
			children: [
				/* @__PURE__ */ jsxs("div", {
					className: "article-meta",
					children: [/* @__PURE__ */ jsx("span", { children: article.category }), /* @__PURE__ */ jsxs("span", { children: [
						/* @__PURE__ */ jsx(Clock, {
							size: 12,
							"aria-hidden": "true"
						}),
						readingMinutes(article),
						" min read"
					] })]
				}),
				/* @__PURE__ */ jsx("h2", { children: /* @__PURE__ */ jsx(Link, {
					to: `/learning-hub/${article.slug}`,
					children: article.title
				}) }),
				/* @__PURE__ */ jsx("p", { children: article.summary }),
				/* @__PURE__ */ jsxs(Link, {
					className: "text-link",
					to: `/learning-hub/${article.slug}`,
					children: ["Read article ", /* @__PURE__ */ jsx(ArrowRight, { size: 16 })]
				})
			]
		})]
	});
}
function LearningHubPage() {
	const [params, setParams] = useSearchParams();
	const visibleParams = useSyncExternalStore(subscribeHydration, () => true, () => false) ? params : new URLSearchParams();
	const pendingParams = useRef(params);
	useEffect(() => {
		pendingParams.current = params;
	}, [params]);
	const selected = articleCategories.includes(visibleParams.get("category")) ? visibleParams.get("category") : "All";
	const query = visibleParams.get("q") ?? "";
	const filtered = articles.filter((article) => (selected === "All" || article.category === selected) && `${article.title} ${article.summary} ${article.category}`.toLowerCase().includes(query.trim().toLowerCase()));
	const revealRoot = useHomepageReveals();
	const setFilter = (key, value) => {
		const next = new URLSearchParams(pendingParams.current);
		if (!value || value === "All") next.delete(key);
		else next.set(key, value);
		pendingParams.current = next;
		setParams(next, { replace: true });
	};
	return /* @__PURE__ */ jsxs("div", {
		className: "learning-page",
		ref: revealRoot,
		children: [
			/* @__PURE__ */ jsx("section", {
				className: "learning-hero",
				children: /* @__PURE__ */ jsxs("div", {
					className: "container",
					children: [/* @__PURE__ */ jsx("nav", {
						className: "academic-breadcrumb",
						"aria-label": "Breadcrumb",
						children: /* @__PURE__ */ jsxs("ol", { children: [/* @__PURE__ */ jsx("li", { children: /* @__PURE__ */ jsx(Link, {
							to: "/",
							children: "Home"
						}) }), /* @__PURE__ */ jsx("li", {
							"aria-current": "page",
							children: "Learning Hub"
						})] })
					}), /* @__PURE__ */ jsxs("div", {
						className: "learning-hero-grid",
						children: [/* @__PURE__ */ jsxs("div", { children: [
							/* @__PURE__ */ jsx("span", {
								className: "eyebrow",
								children: "THE SRI VIDYA LEARNING HUB"
							}),
							/* @__PURE__ */ jsxs("h1", { children: [
								"For the curious.",
								/* @__PURE__ */ jsx("br", {}),
								"For the next step."
							] }),
							/* @__PURE__ */ jsx("p", { children: "Clear explanations, worked examples and practical study ideas. Take one useful idea into your next learning session." })
						] }), /* @__PURE__ */ jsxs("div", {
							className: "learning-hero-note",
							children: [
								/* @__PURE__ */ jsx(BookOpen, {
									size: 34,
									strokeWidth: 1.3,
									"aria-hidden": "true"
								}),
								/* @__PURE__ */ jsx("span", { children: "UNDERSTAND A LITTLE MORE" }),
								/* @__PURE__ */ jsx("p", { children: "Read. Try. Reflect." }),
								/* @__PURE__ */ jsxs("small", { children: [
									"Independent educational notes.",
									/* @__PURE__ */ jsx("br", {}),
									"No exam predictions or outcome guarantees."
								] })
							]
						})]
					})]
				})
			}),
			/* @__PURE__ */ jsx("section", {
				className: "section",
				children: /* @__PURE__ */ jsxs("div", {
					className: "container",
					children: [
						/* @__PURE__ */ jsxs("div", {
							className: "learning-toolbar",
							children: [/* @__PURE__ */ jsxs("div", { children: [/* @__PURE__ */ jsx("span", {
								className: "eyebrow",
								children: "FIND YOUR NEXT READ"
							}), /* @__PURE__ */ jsx("h2", { children: "Ideas to learn with." })] }), /* @__PURE__ */ jsxs("div", {
								className: "article-search",
								children: [/* @__PURE__ */ jsx("label", {
									htmlFor: "article-search",
									children: "Search learning notes"
								}), /* @__PURE__ */ jsxs("div", { children: [/* @__PURE__ */ jsx(Search, {
									size: 18,
									"aria-hidden": "true"
								}), /* @__PURE__ */ jsx("input", {
									id: "article-search",
									type: "search",
									placeholder: "Try algebra or revision",
									value: query,
									onChange: (event) => setFilter("q", event.target.value),
									maxLength: 120
								})] })]
							})]
						}),
						/* @__PURE__ */ jsx("div", {
							className: "showcase-filters learning-filters",
							role: "group",
							"aria-label": "Article categories",
							children: ["All", ...articleCategories].map((category) => /* @__PURE__ */ jsx("button", {
								"aria-pressed": selected === category,
								onClick: () => setFilter("category", category),
								children: category
							}, category))
						}),
						/* @__PURE__ */ jsxs("p", {
							className: "showcase-count",
							role: "status",
							"aria-live": "polite",
							children: [
								filtered.length,
								" ",
								filtered.length === 1 ? "article" : "articles",
								" · ",
								selected
							]
						}),
						filtered.length ? /* @__PURE__ */ jsx("div", {
							className: "learning-grid",
							"data-reveal-group": true,
							children: filtered.map((article) => /* @__PURE__ */ jsx(ArticleCard, { article }, article.slug))
						}, `${selected}-${query}`) : /* @__PURE__ */ jsxs("div", {
							className: "learning-empty",
							children: [
								/* @__PURE__ */ jsx(BookOpen, {
									size: 34,
									"aria-hidden": "true"
								}),
								/* @__PURE__ */ jsx("h2", { children: "No matching notes yet." }),
								/* @__PURE__ */ jsx("p", { children: "Try another topic or clear the filters to browse all articles." }),
								/* @__PURE__ */ jsxs("button", {
									className: "button",
									onClick: () => {
										pendingParams.current = new URLSearchParams();
										setParams({});
									},
									children: ["Browse all articles ", /* @__PURE__ */ jsx(ArrowRight, { size: 17 })]
								})
							]
						})
					]
				})
			}),
			/* @__PURE__ */ jsx("section", {
				className: "learning-bottom",
				children: /* @__PURE__ */ jsxs("div", {
					className: "container",
					children: [/* @__PURE__ */ jsxs("div", { children: [
						/* @__PURE__ */ jsx("span", {
							className: "eyebrow",
							children: "TAKE THE NEXT STEP"
						}),
						/* @__PURE__ */ jsx("h2", { children: "Bring your questions along." }),
						/* @__PURE__ */ jsx("p", { children: "Explore Sri Vidya’s programs or speak with the institute about your learning needs." })
					] }), /* @__PURE__ */ jsxs(Link, {
						to: "/programs",
						className: "button",
						children: ["Explore programs ", /* @__PURE__ */ jsx(ArrowRight, { size: 17 })]
					})]
				})
			})
		]
	});
}
function ArticlePage() {
	const { slug } = useParams();
	const article = articles.find((item) => item.slug === slug);
	if (!article) return /* @__PURE__ */ jsx(NotFound, {});
	const related = article.related.map((id) => articles.find((item) => item.slug === id)).filter((item) => !!item);
	return /* @__PURE__ */ jsxs("div", {
		className: "learning-page article-page",
		children: [
			/* @__PURE__ */ jsx("header", {
				className: "article-header",
				children: /* @__PURE__ */ jsxs("div", {
					className: "container",
					children: [
						/* @__PURE__ */ jsx("nav", {
							className: "academic-breadcrumb",
							"aria-label": "Breadcrumb",
							children: /* @__PURE__ */ jsxs("ol", { children: [
								/* @__PURE__ */ jsx("li", { children: /* @__PURE__ */ jsx(Link, {
									to: "/",
									children: "Home"
								}) }),
								/* @__PURE__ */ jsx("li", { children: /* @__PURE__ */ jsx(Link, {
									to: "/learning-hub",
									children: "Learning Hub"
								}) }),
								/* @__PURE__ */ jsx("li", {
									"aria-current": "page",
									children: article.title
								})
							] })
						}),
						/* @__PURE__ */ jsxs("div", {
							className: "article-title-wrap",
							children: [
								/* @__PURE__ */ jsx(Link, {
									className: "eyebrow",
									to: `/learning-hub?category=${encodeURIComponent(article.category)}`,
									children: article.category
								}),
								/* @__PURE__ */ jsx("h1", { children: article.title }),
								/* @__PURE__ */ jsx("p", { children: article.summary }),
								/* @__PURE__ */ jsxs("div", {
									className: "article-byline",
									children: [
										/* @__PURE__ */ jsx(BookOpen, {
											size: 15,
											"aria-hidden": "true"
										}),
										/* @__PURE__ */ jsx("span", { children: "Sri Vidya Learning Hub · Educational note" }),
										/* @__PURE__ */ jsxs("span", { children: [
											"· ",
											readingMinutes(article),
											" min read"
										] })
									]
								})
							]
						}),
						/* @__PURE__ */ jsx(ArticleCover, {
							article,
							large: true
						})
					]
				})
			}),
			/* @__PURE__ */ jsx("section", {
				className: "section",
				children: /* @__PURE__ */ jsxs("div", {
					className: "container article-reading-layout",
					children: [/* @__PURE__ */ jsxs("aside", {
						className: "article-contents",
						children: [
							/* @__PURE__ */ jsx("h2", { children: "In this article" }),
							/* @__PURE__ */ jsxs("nav", {
								"aria-label": "Article contents",
								children: [article.sections.map((section) => /* @__PURE__ */ jsx("a", {
									href: `#${section.id}`,
									children: section.title
								}, section.id)), /* @__PURE__ */ jsx("a", {
									href: "#try-it",
									children: "Try it yourself"
								})]
							}),
							/* @__PURE__ */ jsxs(Link, {
								className: "text-link",
								to: "/learning-hub",
								children: ["All learning notes ", /* @__PURE__ */ jsx(ArrowRight, { size: 15 })]
							})
						]
					}), /* @__PURE__ */ jsxs("article", {
						className: "article-prose",
						children: [
							/* @__PURE__ */ jsxs("div", {
								className: "article-takeaway",
								children: [/* @__PURE__ */ jsx("span", {
									className: "eyebrow",
									children: "THE IDEA TO KEEP"
								}), /* @__PURE__ */ jsx("p", { children: article.takeaway })]
							}),
							article.sections.map((section) => /* @__PURE__ */ jsxs("section", {
								id: section.id,
								children: [
									/* @__PURE__ */ jsx("h2", { children: section.title }),
									section.paragraphs.map((paragraph) => /* @__PURE__ */ jsx("p", { children: paragraph }, paragraph)),
									section.steps && /* @__PURE__ */ jsx("ol", { children: section.steps.map((step) => /* @__PURE__ */ jsx("li", { children: step }, step)) })
								]
							}, section.id)),
							/* @__PURE__ */ jsxs("section", {
								id: "try-it",
								className: "article-practice",
								children: [
									/* @__PURE__ */ jsx("span", {
										className: "eyebrow",
										children: "TRY IT YOURSELF"
									}),
									/* @__PURE__ */ jsx("h2", { children: article.practice.title }),
									/* @__PURE__ */ jsx("p", { children: article.practice.task }),
									/* @__PURE__ */ jsxs("details", { children: [/* @__PURE__ */ jsxs("summary", { children: ["Check your reasoning ", /* @__PURE__ */ jsx("span", {
										"aria-hidden": "true",
										children: "+"
									})] }), /* @__PURE__ */ jsx("p", { children: article.practice.answer })] })
								]
							}),
							article.sources.length > 0 && /* @__PURE__ */ jsxs("section", {
								className: "article-sources",
								children: [
									/* @__PURE__ */ jsx("h2", { children: "Sources & further reading" }),
									/* @__PURE__ */ jsx("p", { children: "Use official exam portals for the syllabus and rules for your intended exam year. Research references describe study findings, not guaranteed individual outcomes." }),
									/* @__PURE__ */ jsx("ul", { children: article.sources.map((source) => /* @__PURE__ */ jsx("li", { children: /* @__PURE__ */ jsxs("a", {
										href: source.url,
										target: "_blank",
										rel: "noopener noreferrer",
										children: [source.title, " ↗"]
									}) }, source.url)) })
								]
							}),
							/* @__PURE__ */ jsx("div", {
								className: "article-editorial-note",
								children: /* @__PURE__ */ jsx("p", { children: "General educational guidance. These notes do not claim institute results, individual faculty credentials or a confirmed Sri Vidya timetable." })
							})
						]
					})]
				})
			}),
			/* @__PURE__ */ jsx("section", {
				className: "section related-reading",
				children: /* @__PURE__ */ jsxs("div", {
					className: "container",
					children: [
						/* @__PURE__ */ jsx("span", {
							className: "eyebrow",
							children: "KEEP THE CURIOSITY GOING"
						}),
						/* @__PURE__ */ jsx("h2", { children: "Read a little further." }),
						/* @__PURE__ */ jsx("div", {
							className: "learning-grid related-learning-grid",
							children: related.map((item) => /* @__PURE__ */ jsx(ArticleCard, { article: item }, item.slug))
						})
					]
				})
			})
		]
	});
}
// src/components/WhatsAppIcon.tsx
function WhatsAppIcon({ size = 22 }) {
	return /* @__PURE__ */ jsx("svg", {
		xmlns: "http://www.w3.org/2000/svg",
		width: size,
		height: size,
		viewBox: "0 0 24 24",
		fill: "currentColor",
		"aria-hidden": "true",
		focusable: "false",
		children: /* @__PURE__ */ jsx("path", { d: "M20.52 3.48A11.91 11.91 0 0 0 12.04 0C5.45 0 .08 5.37.08 11.97c0 2.11.55 4.17 1.6 5.99L0 24l6.2-1.63a11.96 11.96 0 0 0 5.83 1.49h.01c6.6 0 11.96-5.37 11.96-11.97 0-3.2-1.24-6.2-3.48-8.41ZM12.04 21.84a9.9 9.9 0 0 1-5.04-1.38l-.36-.21-3.68.96.98-3.58-.24-.37a9.89 9.89 0 0 1-1.52-5.29c0-5.48 4.46-9.94 9.95-9.94a9.87 9.87 0 0 1 7.03 2.91 9.88 9.88 0 0 1 2.91 7.04c0 5.48-4.46 9.94-9.94 9.94Zm5.43-7.46c-.3-.15-1.76-.87-2.03-.97-.27-.1-.47-.15-.67.15-.2.3-.77.97-.94 1.17-.17.2-.35.22-.64.07-.3-.15-1.26-.46-2.4-1.48-.89-.79-1.49-1.77-1.66-2.07-.18-.3-.02-.46.13-.61.13-.13.3-.35.45-.52.15-.17.2-.3.3-.5.1-.2.05-.37-.03-.52-.07-.15-.67-1.61-.91-2.21-.24-.58-.49-.5-.67-.51h-.57c-.2 0-.52.07-.79.37-.27.3-1.04 1.02-1.04 2.48s1.07 2.88 1.21 3.08c.15.2 2.11 3.22 5.11 4.52.71.3 1.27.49 1.7.63.71.23 1.36.2 1.87.12.57-.09 1.76-.72 2.01-1.41.25-.7.25-1.29.17-1.42-.07-.12-.27-.2-.57-.35Z" })
	});
}
// src/config/academics.ts
var methodology = [
	"Understand the underlying concept.",
	"Apply ideas through focused practice.",
	"Assess understanding and revisit gaps.",
	"Improve through reflection and further practice."
];
var programs = [
	{
		slug: "school-academics-foundation",
		name: "Classes 4–10 School Academics/Foundation",
		description: "Build academic foundations and concept understanding through the school years.",
		label: "CLASSES 4–10",
		focus: "School academics · Foundation",
		overview: "A school-stage pathway focused on understanding concepts and strengthening academic foundations. Discuss the student’s current class and learning needs with the institute.",
		subjects: [],
		curriculum: [],
		eligibility: "Intended for students in Classes 4–10. Confirm class-specific admission requirements with the institute.",
		methodology
	},
	{
		slug: "board-jee-neet",
		name: "Classes 11–12 Board + JEE + NEET",
		description: "Connect board-level learning with preparation for engineering and medical entrance examinations.",
		label: "CLASSES 11–12",
		focus: "Boards · JEE · NEET",
		overview: "A pathway connecting senior-secondary academics with competitive-exam preparation. Contact the institute to discuss the appropriate board and entrance-exam focus.",
		subjects: [],
		curriculum: [],
		eligibility: "Intended for students in Classes 11–12. Confirm the applicable board, stream and admission requirements with the institute.",
		methodology
	},
	{
		slug: "organic-chemistry-mentorship",
		name: "Organic Chemistry Mentorship",
		description: "Explore organic chemistry with a focus on concepts, connections and problem-solving.",
		label: "SUBJECT MENTORSHIP",
		focus: "Organic chemistry",
		overview: "Subject-focused mentorship in organic chemistry. Discuss your current level, areas of difficulty and academic goals before choosing a starting point.",
		subjects: ["Organic Chemistry"],
		curriculum: [],
		eligibility: "Contact the institute to confirm the appropriate starting level and any prerequisite knowledge.",
		methodology
	}
];
var faculty = [{
	id: "balu-mahendra",
	name: "T. Balu Mahendra",
	focus: "Chemistry mentorship",
	introduction: "At the heart of Sri Vidya Classes, T. Balu Mahendra sir brings the focus back to understanding: exploring ideas, asking questions and applying concepts through practice.",
	qualifications: [],
	portrait: ""
}];
var faqCategories = [
	{
		id: "classes",
		title: "Classes & programs",
		items: [{
			question: "Which classes and programs can I enquire about?",
			answer: "Enquire about Classes 4–10 School Academics/Foundation, Classes 11–12 Board + JEE + NEET, and Organic Chemistry Mentorship. Confirm current availability with the institute."
		}, {
			question: "Are class timings available online?",
			answer: "Confirmed batch timings are not yet published. Contact the institute for the schedule relevant to your class and program."
		}]
	},
	{
		id: "admissions",
		title: "Admissions",
		items: [{
			question: "How can I start an admission enquiry?",
			answer: "Call 9959010394 or visit the Contact page. Share the student’s class and program of interest to discuss the next steps."
		}, {
			question: "Where can I check fees and eligibility?",
			answer: "The program pages describe the intended class range. Contact the institute for confirmed eligibility, fees, documents and admission requirements."
		}]
	},
	{
		id: "curriculum",
		title: "Curriculum",
		items: [{
			question: "Where can I find a detailed syllabus?",
			answer: "Detailed subject lists and curriculum outlines will be added after approval. Ask the institute about the syllabus applicable to your class, board and program."
		}, {
			question: "Can I enquire specifically about organic chemistry?",
			answer: "Yes. Organic Chemistry Mentorship is a dedicated program. Discuss your current level and goals with the institute to confirm suitability."
		}]
	},
	{
		id: "tests",
		title: "Tests & practice",
		items: [{
			question: "How do tests fit into the teaching approach?",
			answer: "Assessment helps identify understanding and the concepts that need more practice. Confirm the applicable test format and frequency directly with the institute."
		}, {
			question: "Are results or performance guarantees published?",
			answer: "No performance guarantees are made. Only verified, approved result records will be published when available."
		}]
	},
	{
		id: "counselling",
		title: "Counselling & guidance",
		items: [{
			question: "How can I discuss which program is suitable?",
			answer: "Call the institute with the student’s class, academic goals and areas where support is needed. Ask about suitable programs and whether a guidance conversation can be arranged."
		}, {
			question: "Can parents contact the institute with questions?",
			answer: "Yes. Parents can use the published phone number to ask about programs and admission next steps. Confirm appointment availability before visiting."
		}]
	}
];
var academicImages = {
	about: "",
	environment: "",
	programs: "",
	faqs: ""
};
// src/config/contact.ts
var contact = {
	name: "Sri Vidya Classes",
	address: "APHB Colony, beside Bandhan Bank, near Rajeev Park, Kadapa – 516001",
	postalAddress: {
		streetAddress: "APHB Colony, beside Bandhan Bank, near Rajeev Park",
		addressLocality: "Kadapa",
		addressRegion: "Andhra Pradesh",
		postalCode: "516001",
		addressCountry: "IN"
	},
	phone: "9959010394",
	secondaryPhone: "8639850172",
	whatsapp: "919959010394"
};
// src/config/showcase.ts
var achievements = [];
var galleryPhotos = [];
var resultCategories = [
	"Board",
	"IIT-JEE",
	"NEET",
	"Foundation"
];
var galleryCategories = [
	"Classroom",
	"Activities",
	"Events",
	"Achievements"
];
function isApprovedPhoto(photo) {
	return photo.approved && photo.consentConfirmed && !!photo.src.trim() && !!photo.alt.trim() && photo.width > 0 && photo.height > 0;
}
function publishableAchievements(records) {
	return records.filter((record) => record.verified && record.approved && isApprovedPhoto(record.photo) && record.studentName.trim() && record.exam.trim() && record.result.trim() && record.description.trim() && Number.isInteger(record.year) && record.year > 0 && (record.context === "sri-vidya-coaching" || record.context === "external-achievement" && record.institutionName?.trim()));
}
function publishableGallery(records) {
	return records.filter((photo) => isApprovedPhoto(photo) && photo.institutePhoto && photo.caption.trim());
}
// src/config/seo.ts
var seoPolicy = {
	"siteUrl": "https://sri-vidya-classes.invalid",
	"production": false,
	"domainVerified": false,
	"indexing": false
};
var publicRoutes = [
	...[
		{
			path: "/",
			title: "Sri Vidya Classes, Kadapa | IIT-JEE, NEET & Foundation",
			description: "Explore school foundation, Classes 11–12 Board + JEE + NEET and Organic Chemistry Mentorship at Sri Vidya Classes, Kadapa, with T. Balu Mahendra sir.",
			label: "Home",
			indexable: true
		},
		{
			path: "/about",
			title: "About Sri Vidya Classes, Kadapa | Learning with Understanding",
			description: "Discover the teaching philosophy, learning values and academic focus of Sri Vidya Classes in Kadapa, with T. Balu Mahendra sir at its heart.",
			label: "About",
			indexable: true
		},
		{
			path: "/faculty",
			title: "T. Balu Mahendra sir | Sri Vidya Classes Faculty, Kadapa",
			description: "Meet T. Balu Mahendra sir at Sri Vidya Classes, Kadapa. Explore Chemistry mentorship and a teaching approach focused on understanding and practice.",
			label: "Faculty",
			indexable: true
		},
		{
			path: "/programs",
			title: "Academic Programs in Kadapa | Sri Vidya Classes",
			description: "Explore Classes 4–10 School Academics/Foundation, Classes 11–12 Board + JEE + NEET and Organic Chemistry Mentorship. Enquire about suitability and availability.",
			label: "Programs",
			indexable: true
		},
		{
			path: "/admissions",
			title: "Admission Enquiry | Sri Vidya Classes, Kadapa",
			description: "Choose your class, board and program to prepare an admission enquiry for Sri Vidya Classes, Kadapa. Review your details and choose when to send through WhatsApp.",
			label: "Admissions",
			indexable: true
		},
		{
			path: "/contact",
			title: "Contact Sri Vidya Classes | APHB Colony, Kadapa",
			description: "Contact Sri Vidya Classes on 9959010394. Find the institute at APHB Colony, beside Bandhan Bank, near Rajeev Park, Kadapa 516001. Please call before visiting.",
			label: "Contact",
			indexable: true
		},
		{
			path: "/faqs",
			title: "Classes & Admissions FAQs | Sri Vidya Classes, Kadapa",
			description: "Find answers about classes, programs, admission enquiries, curriculum, practice and guidance at Sri Vidya Classes. Contact the institute for confirmed details.",
			label: "FAQs",
			indexable: true
		},
		{
			path: "/learning-hub",
			title: "Learning Hub | JEE, NEET, Chemistry & Study Notes",
			description: "Read educational notes on concept-based learning, JEE and NEET preparation, school foundations, study techniques and organic chemistry, with worked exercises.",
			label: "Learning Hub",
			indexable: true
		},
		{
			path: "/counselling",
			title: "Academic Guidance Enquiries | Sri Vidya Classes, Kadapa",
			description: "Ask about suitable academic pathways at Sri Vidya Classes. Share the student’s class and goals; scheduled counselling and demo classes are not yet confirmed.",
			label: "Counselling & guidance",
			indexable: true
		},
		{
			path: "/results",
			title: "Verified Results & Achievements | Sri Vidya Classes",
			description: "A space for verified, approved student achievements at Sri Vidya Classes, with clear coaching and external-institution context. Records are shared only with permission.",
			label: "Results & Achievements",
			indexable: publishableAchievements(achievements).length > 0
		},
		{
			path: "/gallery",
			title: "Classroom & Events Gallery | Sri Vidya Classes, Kadapa",
			description: "Explore approved Sri Vidya Classes photographs across Classroom, Activities, Events and Achievements. Institute photographs are shared only with permission.",
			label: "Gallery",
			indexable: publishableGallery(galleryPhotos).length > 0
		},
		{
			path: "/privacy",
			title: "Privacy & Enquiry Information | Sri Vidya Classes",
			description: "Learn how Sri Vidya Classes enquiry forms use browser-tab drafts, consent and WhatsApp handoff. Reviewing a form does not submit your information.",
			label: "Privacy",
			indexable: true
		},
		{
			path: "/terms",
			title: "Website Terms | Sri Vidya Classes",
			description: "Read the current website information and terms notice for Sri Vidya Classes. An enquiry does not reserve a place or confirm admission.",
			label: "Terms",
			indexable: false
		}
	],
	...programs.map((program) => ({
		path: `/programs/${program.slug}`,
		title: program.slug === "school-academics-foundation" ? "Classes 4–10 Foundation, Kadapa | Sri Vidya Classes" : program.slug === "board-jee-neet" ? "Classes 11–12 Board, JEE & NEET | Sri Vidya Classes, Kadapa" : "Organic Chemistry Mentorship, Kadapa | Sri Vidya Classes",
		description: program.description + " Explore the overview, learning approach and eligibility; contact Sri Vidya Classes in Kadapa for confirmed details.",
		label: program.name,
		indexable: true
	})),
	...articles.map((article) => ({
		path: `/learning-hub/${article.slug}`,
		title: `${article.title} | Sri Vidya Learning Hub`,
		description: article.summary,
		label: article.title,
		indexable: true
	}))
];
function normalizePath(input) {
	const path = input.split(/[?#]/)[0];
	return path === "/" ? "/" : path.replace(/\/+$/, "") || "/";
}
function absoluteUrl(path, policy = seoPolicy) {
	return new URL(path, policy.siteUrl + "/").href;
}
function getPageSeo(input, policy = seoPolicy) {
	const path = normalizePath(input);
	const route = publicRoutes.find((item) => item.path === path);
	const article = articles.find((item) => `/learning-hub/${item.slug}` === path);
	const program = programs.find((item) => `/programs/${item.slug}` === path);
	const title = route?.title ?? "Page Not Found | Sri Vidya Classes, Kadapa";
	const description = route?.description ?? "This page is unavailable. Explore Sri Vidya Classes programs, learning notes or contact the institute in Kadapa.";
	const canonical = absoluteUrl(route ? path : "/404.html", policy);
	const image = absoluteUrl(`/social/${path === "/" ? "home" : route ? path.slice(1).replaceAll("/", "-") : "404"}.png`, policy);
	const breadcrumbs = [
		{
			name: "Home",
			url: absoluteUrl("/", policy)
		},
		...program ? [{
			name: "Programs",
			url: absoluteUrl("/programs", policy)
		}] : article ? [{
			name: "Learning Hub",
			url: absoluteUrl("/learning-hub", policy)
		}] : [],
		...path !== "/" && route ? [{
			name: route.label,
			url: canonical
		}] : []
	];
	const organizationId = absoluteUrl("/#organization", policy);
	const graph = [{
		"@type": "EducationalOrganization",
		"@id": organizationId,
		name: contact.name,
		url: absoluteUrl("/", policy),
		description: "School academics, foundation learning, Board + JEE + NEET preparation and Organic Chemistry Mentorship in Kadapa.",
		logo: {
			"@type": "ImageObject",
			url: absoluteUrl("/sri-vidya-icon-512.png", policy),
			width: 512,
			height: 512
		},
		image: absoluteUrl("/social/home.png", policy),
		telephone: `+91${contact.phone}`,
		address: {
			"@type": "PostalAddress",
			...contact.postalAddress
		},
		areaServed: {
			"@type": "City",
			name: "Kadapa"
		},
		contactPoint: {
			"@type": "ContactPoint",
			telephone: `+91${contact.phone}`,
			contactType: "admission enquiries"
		}
	}];
	if (route) {
		graph.push({
			"@type": path === "/about" ? "AboutPage" : path === "/contact" ? "ContactPage" : path === "/programs" || path === "/learning-hub" ? "CollectionPage" : "WebPage",
			"@id": canonical + "#webpage",
			url: canonical,
			name: title,
			description,
			inLanguage: "en-IN",
			about: { "@id": organizationId },
			...path !== "/" ? { breadcrumb: { "@id": canonical + "#breadcrumb" } } : {}
		});
		if (path !== "/") graph.push({
			"@type": "BreadcrumbList",
			"@id": canonical + "#breadcrumb",
			itemListElement: breadcrumbs.map((item, index) => ({
				"@type": "ListItem",
				position: index + 1,
				name: item.name,
				item: item.url
			}))
		});
		const course = (item) => ({
			"@type": "Course",
			"@id": absoluteUrl(`/programs/${item.slug}#course`, policy),
			name: item.name,
			description: item.description,
			url: absoluteUrl(`/programs/${item.slug}`, policy),
			courseCode: item.slug,
			educationalLevel: item.label,
			provider: { "@id": organizationId }
		});
		if (program) graph.push(course(program));
		if (path === "/programs") {
			graph.push(...programs.map(course));
			graph.push({
				"@type": "ItemList",
				itemListElement: programs.map((item, index) => ({
					"@type": "ListItem",
					position: index + 1,
					item: { "@id": absoluteUrl(`/programs/${item.slug}#course`, policy) }
				}))
			});
		}
		if (article) graph.push({
			"@type": "Article",
			"@id": canonical + "#article",
			mainEntityOfPage: { "@id": canonical + "#webpage" },
			headline: article.title,
			description: article.summary,
			image: [image],
			articleSection: article.category,
			inLanguage: "en-IN",
			author: {
				"@type": "Organization",
				name: "Sri Vidya Learning Hub",
				url: absoluteUrl("/learning-hub", policy)
			},
			publisher: { "@id": organizationId },
			citation: article.sources.map((source) => source.url)
		});
	}
	return {
		path,
		route,
		title,
		description,
		canonical,
		image,
		breadcrumbs,
		status: route ? 200 : 404,
		robots: policy.indexing && route?.indexable ? "index,follow,max-image-preview:large" : "noindex,nofollow",
		type: article ? "article" : "website",
		schema: {
			"@context": "https://schema.org",
			"@graph": graph
		}
	};
}
var escapeHtml = (value) => value.replaceAll("&", "&amp;").replaceAll("<", "&lt;").replaceAll(">", "&gt;").replaceAll("\"", "&quot;").replaceAll("'", "&#39;");
function renderSeoHead(path, policy = seoPolicy) {
	const seo = getPageSeo(path, policy), escape = escapeHtml;
	const meta = (key, value, property = false) => `<meta ${property ? "property" : "name"}="${key}" content="${escape(value)}" data-seo="true">`;
	return [
		`<title data-seo="true">${escape(seo.title)}</title>`,
		meta("description", seo.description),
		meta("robots", seo.robots),
		`<link rel="canonical" href="${escape(seo.canonical)}" data-seo="true">`,
		meta("og:type", seo.type, true),
		meta("og:site_name", contact.name, true),
		meta("og:locale", "en_IN", true),
		meta("og:title", seo.title, true),
		meta("og:description", seo.description, true),
		meta("og:url", seo.canonical, true),
		meta("og:image", seo.image, true),
		meta("og:image:secure_url", seo.image, true),
		meta("og:image:type", "image/png", true),
		meta("og:image:width", "1200", true),
		meta("og:image:height", "630", true),
		meta("og:image:alt", `${contact.name}, Kadapa — official crest and T. Balu Mahendra sir`, true),
		meta("twitter:card", "summary_large_image"),
		meta("twitter:title", seo.title),
		meta("twitter:description", seo.description),
		meta("twitter:image", seo.image),
		meta("twitter:image:alt", `${contact.name}, Kadapa — official crest and T. Balu Mahendra sir`),
		`<script type="application/ld+json" data-seo="true">${JSON.stringify(seo.schema).replaceAll("<", "\\u003c")}<\/script>`
	].join("\n");
}
// src/lib/analytics.ts
var allowedEvents = [
	"admission_enquiry_reviewed",
	"contact_enquiry_reviewed",
	"program_interest",
	"whatsapp_opened",
	"call_clicked"
];
var consent = false;
function privacySignal() {
	return typeof navigator !== "undefined" && (navigator.doNotTrack === "1" || navigator.globalPrivacyControl === true);
}
function trackEvent(event, programId) {
	if (typeof window === "undefined" || !consent || privacySignal() || !allowedEvents.includes(event)) return;
	const known = publicRoutes.find((route) => route.path === window.location.pathname.replace(/\/$/, "") || route.path === "/" && window.location.pathname === "/");
	const program = programs.find((item) => item.slug === programId);
	window.dispatchEvent(new CustomEvent("sri-vidya:analytics", { detail: {
		event,
		path: known?.path ?? "/404",
		...program ? { programId: program.slug } : {}
	} }));
}
// src/assets/branding/sri-vidya-crest.webp
var sri_vidya_crest_default = "/assets/sri-vidya-crest-Csllp8yh.webp";
// src/assets/faculty/t-balu-mahendra-800.webp
var t_balu_mahendra_800_default = "/assets/t-balu-mahendra-800-B1792Ddj.webp";
// src/assets/faculty/t-balu-mahendra-480.webp
var t_balu_mahendra_480_default = "/assets/t-balu-mahendra-480-CZ_Plzo_.webp";
// src/assets/faculty/t-balu-mahendra-1086.webp
var t_balu_mahendra_1086_default = "/assets/t-balu-mahendra-1086-DgPfdpxY.webp";
// src/config/institute.ts
var institute = {
	...contact,
	openingHours: "",
	counsellingOffered: false,
	demoClassOffered: false,
	logo: sri_vidya_crest_default,
	facultyPhoto: t_balu_mahendra_800_default,
	facultyPhotoSrcSet: `${t_balu_mahendra_480_default} 480w, ${t_balu_mahendra_800_default} 800w, ${t_balu_mahendra_1086_default} 1086w`,
	socials: []
};
// src/lib/enquiry.ts
var classOptions = Array.from({ length: 9 }, (_, index) => String(index + 4));
var boardOptions = [
	"Andhra Pradesh State Board",
	"CBSE",
	"ICSE / ISC",
	"Other",
	"Not sure yet"
];
var emptyEnquiry = {
	studentName: "",
	classLevel: "",
	board: "",
	program: "",
	guardianName: "",
	contactName: "",
	phone: "",
	message: "",
	consent: false,
	request: "Admission enquiry"
};
function validateEnquiry(values, kind) {
	const errors = {};
	const name = (key, label) => {
		const value = values[key].trim();
		if (value.length < 2 || value.length > 80 || Array.from(value).some((character) => character.charCodeAt(0) < 32) || !/[\p{L}]/u.test(value)) errors[key] = `Enter ${label} (2–80 characters).`;
	};
	if (kind === "admission") {
		name("studentName", "the student’s name");
		name("guardianName", "the parent or guardian’s name");
		if (!classOptions.includes(values.classLevel)) errors.classLevel = "Select a class from 4 to 12.";
		if (!boardOptions.includes(values.board)) errors.board = "Select your board or “Not sure yet”.";
		if (!programs.some((program) => program.slug === values.program)) errors.program = "Select the program you’re interested in.";
	} else name("contactName", "your name");
	if (!/^(?:\+91[\s-]?)?[6-9]\d{9}$/.test(values.phone.trim())) errors.phone = "Enter a valid 10-digit Indian mobile number, optionally prefixed with +91.";
	if (values.message.length > 1e3) errors.message = "Keep your message within 1,000 characters.";
	if (kind === "contact" && values.message.trim().length < 10) errors.message = "Please write a message of at least 10 characters.";
	if (!values.consent) errors.consent = "Please confirm your consent before continuing.";
	const requests = [
		"Admission enquiry",
		...institute.counsellingOffered ? ["Counselling request"] : [],
		...institute.demoClassOffered ? ["Demo-class request"] : []
	];
	if (kind === "admission" && !requests.includes(values.request)) errors.request = "Select an available enquiry type.";
	return errors;
}
function whatsappUrl(message) {
	return /^\d{8,15}$/.test(institute.whatsapp) ? `https://wa.me/${institute.whatsapp}?text=${encodeURIComponent(message)}` : null;
}
function formatEnquiry(values, kind) {
	const lines = [
		"Hello Sri Vidya Classes,",
		"",
		kind === "admission" ? `I would like to make the following request: ${values.request.toLowerCase()}.` : "I would like to contact the institute.",
		""
	];
	if (kind === "admission") lines.push(`Student: ${values.studentName.trim()}`, `Class: ${values.classLevel}`, `Board: ${values.board}`, `Program: ${programs.find((program) => program.slug === values.program)?.name ?? values.program}`, `Parent / guardian: ${values.guardianName.trim()}`);
	else lines.push(`Name: ${values.contactName.trim()}`);
	lines.push(`Contact number: ${values.phone.trim()}`);
	if (values.message.trim()) lines.push("", `Message: ${values.message.trim()}`);
	lines.push("", "I consent to sharing these details with Sri Vidya Classes for a response to this enquiry.", "", "Please let me know the appropriate next steps. Thank you.");
	return lines.join("\n");
}
var draftKey = (kind) => `sri-vidya-enquiry-${kind}-v1`;
function loadDraft(kind) {
	try {
		const stored = JSON.parse(sessionStorage.getItem(draftKey(kind)) ?? "null");
		if (!stored || typeof stored.expires !== "number" || stored.expires < Date.now()) {
			sessionStorage.removeItem(draftKey(kind));
			return { ...emptyEnquiry };
		}
		const values = { ...emptyEnquiry };
		for (const key of Object.keys(emptyEnquiry)) if (key === "consent") values.consent = stored.values?.consent === true;
		else if (typeof stored.values?.[key] === "string") values[key] = stored.values[key].slice(0, 1e3);
		return values;
	} catch {
		return { ...emptyEnquiry };
	}
}
function saveDraft(kind, values) {
	sessionStorage.setItem(draftKey(kind), JSON.stringify({
		values,
		expires: Date.now() + 864e5
	}));
}
// src/components/EnquiryForm.tsx
function EnquiryForm({ kind }) {
	const [values, setValues] = useState(() => ({ ...emptyEnquiry }));
	const [errors, setErrors] = useState({});
	const [review, setReview] = useState(false);
	const [status, setStatus] = useState("");
	const [storageUnavailable, setStorageUnavailable] = useState(false);
	const form = useRef(null);
	const preview = useRef(null);
	useEffect(() => {
		const frame = requestAnimationFrame(() => setValues(loadDraft(kind)));
		return () => cancelAnimationFrame(frame);
	}, [kind]);
	const update = (key, value) => {
		const next = {
			...values,
			[key]: value
		};
		setValues(next);
		setReview(false);
		setStatus("");
		try {
			saveDraft(kind, next);
		} catch {
			setStorageUnavailable(true);
		}
		setErrors((current) => ({
			...current,
			[key]: void 0
		}));
	};
	const submit = (event) => {
		event.preventDefault();
		const issues = validateEnquiry(values, kind);
		setErrors(issues);
		setStatus("");
		if (Object.keys(issues).length) {
			setReview(false);
			requestAnimationFrame(() => form.current?.querySelector("[aria-invalid=\"true\"]")?.focus());
			return;
		}
		trackEvent(kind === "admission" ? "admission_enquiry_reviewed" : "contact_enquiry_reviewed", kind === "admission" ? values.program : void 0);
		setReview(true);
		requestAnimationFrame(() => document.getElementById(`${kind}-review-title`)?.focus());
	};
	const field = (key, label, options, optional = false) => {
		const id = `${kind}-${key}`;
		const common = {
			id,
			name: key,
			"aria-invalid": !!errors[key],
			"aria-describedby": errors[key] ? `${id}-error` : void 0,
			required: !optional,
			value: String(values[key]),
			onChange: (event) => update(key, event.target.value)
		};
		return /* @__PURE__ */ jsxs("div", {
			className: `enquiry-field ${key === "message" ? "field-full" : ""}`,
			children: [
				/* @__PURE__ */ jsxs("label", {
					htmlFor: id,
					children: [label, optional ? /* @__PURE__ */ jsx("span", { children: "Optional" }) : /* @__PURE__ */ jsx("span", {
						"aria-hidden": "true",
						children: "*"
					})]
				}),
				options ? /* @__PURE__ */ jsxs("select", {
					...common,
					children: [/* @__PURE__ */ jsxs("option", {
						value: "",
						children: ["Select ", label.toLowerCase()]
					}), options.map((option) => typeof option === "string" ? /* @__PURE__ */ jsx("option", {
						value: option,
						children: option
					}, option) : /* @__PURE__ */ jsx("option", {
						value: option.value,
						children: option.label
					}, option.value))]
				}) : key === "message" ? /* @__PURE__ */ jsx("textarea", {
					...common,
					rows: 4,
					maxLength: 1e3,
					placeholder: "Please avoid sensitive information such as Aadhaar numbers or medical details."
				}) : /* @__PURE__ */ jsx("input", {
					...common,
					type: key === "phone" ? "tel" : "text",
					inputMode: key === "phone" ? "tel" : "text",
					autoComplete: key === "phone" ? "tel" : key === "contactName" || key === "guardianName" ? "name" : "off",
					maxLength: key === "phone" ? 16 : 80
				}),
				key === "message" && /* @__PURE__ */ jsxs("span", {
					className: "field-hint",
					children: [values.message.length, "/1,000 characters"]
				}),
				errors[key] && /* @__PURE__ */ jsx("p", {
					className: "field-error",
					id: `${id}-error`,
					children: errors[key]
				})
			]
		}, key);
	};
	const text = formatEnquiry(values, kind);
	const url = whatsappUrl(text);
	return /* @__PURE__ */ jsxs("div", {
		className: "enquiry-form-card",
		children: [
			/* @__PURE__ */ jsxs("div", {
				className: "enquiry-form-heading",
				children: [
					/* @__PURE__ */ jsx("span", {
						className: "eyebrow",
						children: kind === "admission" ? "YOUR NEXT CHAPTER" : "WE’RE LISTENING"
					}),
					/* @__PURE__ */ jsx("h2", { children: kind === "admission" ? "Let’s start your enquiry." : "How can we help?" }),
					/* @__PURE__ */ jsx("p", { children: "Complete the details, review your message, then continue to WhatsApp. You must press Send there." })
				]
			}),
			/* @__PURE__ */ jsxs("form", {
				ref: form,
				noValidate: true,
				onSubmit: submit,
				"aria-label": kind === "admission" ? "Admission enquiry" : "Contact enquiry",
				children: [
					/* @__PURE__ */ jsx("p", {
						className: "required-note",
						children: "Fields marked * are required."
					}),
					Object.values(errors).some(Boolean) && /* @__PURE__ */ jsx("div", {
						className: "form-error-summary",
						role: "alert",
						children: "Please check the highlighted fields. Your entered details are still here."
					}),
					/* @__PURE__ */ jsxs("div", {
						className: "enquiry-fields",
						children: [kind === "admission" ? /* @__PURE__ */ jsxs(Fragment, { children: [
							field("studentName", "Student name"),
							field("guardianName", "Parent / guardian name"),
							field("classLevel", "Class", classOptions.map((value) => ({
								value,
								label: `Class ${value}`
							}))),
							field("board", "Board", boardOptions),
							field("program", "Interested program", programs.map((program) => ({
								value: program.slug,
								label: program.name
							}))),
							field("phone", "Contact number"),
							(institute.counsellingOffered || institute.demoClassOffered) && field("request", "Enquiry type", [
								"Admission enquiry",
								...institute.counsellingOffered ? ["Counselling request"] : [],
								...institute.demoClassOffered ? ["Demo-class request"] : []
							])
						] }) : /* @__PURE__ */ jsxs(Fragment, { children: [field("contactName", "Your name"), field("phone", "Contact number")] }), field("message", "Message", void 0, kind === "admission")]
					}),
					/* @__PURE__ */ jsxs("div", {
						className: "consent-field",
						children: [/* @__PURE__ */ jsx("input", {
							id: `${kind}-consent`,
							name: "consent",
							type: "checkbox",
							checked: values.consent,
							required: true,
							"aria-invalid": !!errors.consent,
							"aria-describedby": errors.consent ? `${kind}-consent-error` : void 0,
							onChange: (event) => update("consent", event.target.checked)
						}), /* @__PURE__ */ jsxs("label", {
							htmlFor: `${kind}-consent`,
							children: ["I am a parent/guardian or an adult enquirer. I agree to share these details with Sri Vidya Classes through WhatsApp for a response to my enquiry. ", /* @__PURE__ */ jsx(Link, {
								to: "/privacy",
								children: "Privacy information"
							})]
						})]
					}),
					errors.consent && /* @__PURE__ */ jsx("p", {
						className: "field-error",
						id: `${kind}-consent-error`,
						children: errors.consent
					}),
					/* @__PURE__ */ jsxs("div", {
						className: "form-buttons",
						children: [/* @__PURE__ */ jsxs("button", {
							type: "submit",
							className: "button",
							children: ["Review enquiry ", /* @__PURE__ */ jsx(ArrowRight, { size: 17 })]
						}), /* @__PURE__ */ jsxs("button", {
							type: "button",
							className: "clear-draft",
							onClick: () => {
								setValues({ ...emptyEnquiry });
								setErrors({});
								setReview(false);
								setStatus("Draft cleared.");
								try {
									sessionStorage.removeItem(draftKey(kind));
								} catch {}
							},
							children: [/* @__PURE__ */ jsx(RotateCcw, { size: 15 }), "Clear draft"]
						})]
					}),
					/* @__PURE__ */ jsxs("p", {
						className: "draft-notice",
						children: [storageUnavailable ? "Browser storage is unavailable. Your draft stays on this page while open but may not survive navigation." : "Your draft is saved in this browser tab for up to 24 hours, including across navigation. Clear it when using a shared device.", " Nothing is sent by reviewing this form."]
					})
				]
			}),
			review && /* @__PURE__ */ jsxs("section", {
				className: "enquiry-review",
				"aria-labelledby": `${kind}-review-title`,
				children: [
					/* @__PURE__ */ jsxs("h3", {
						id: `${kind}-review-title`,
						tabIndex: -1,
						children: [/* @__PURE__ */ jsx(Check, { size: 20 }), "Review before sending"]
					}),
					/* @__PURE__ */ jsx("label", {
						htmlFor: `${kind}-preview`,
						children: "Your WhatsApp message"
					}),
					/* @__PURE__ */ jsx("textarea", {
						ref: preview,
						id: `${kind}-preview`,
						readOnly: true,
						value: text,
						rows: 12
					}),
					/* @__PURE__ */ jsx("p", { children: "These details have not been sent. WhatsApp opens with this message filled in; check the recipient and press Send there." }),
					/* @__PURE__ */ jsxs("div", {
						className: "review-actions",
						children: [url ? /* @__PURE__ */ jsxs("a", {
							className: "button",
							href: url,
							target: "_blank",
							rel: "noopener noreferrer",
							onClick: () => setStatus("WhatsApp may open in another tab or app. Press Send there to share your enquiry. This website cannot confirm delivery."),
							children: [/* @__PURE__ */ jsx(WhatsAppIcon, { size: 20 }), "Continue to WhatsApp"]
						}) : /* @__PURE__ */ jsx("p", {
							className: "whatsapp-unavailable",
							children: "The WhatsApp number is awaiting confirmation. Please call the institute; your enquiry has not been sent."
						}), /* @__PURE__ */ jsxs("button", {
							type: "button",
							className: "copy-enquiry",
							onClick: async () => {
								try {
									await navigator.clipboard.writeText(text);
									setStatus("Message copied. It has not been sent.");
								} catch {
									preview.current?.focus();
									preview.current?.select();
									setStatus("Select and copy the message above. It has not been sent.");
								}
							},
							children: [/* @__PURE__ */ jsx(Copy, { size: 16 }), "Copy message"]
						})]
					})
				]
			}),
			/* @__PURE__ */ jsx("p", {
				className: "form-status",
				role: "status",
				"aria-live": "polite",
				children: status
			})
		]
	});
}
// src/pages/EnquiryPages.tsx
function Breadcrumb({ name }) {
	return /* @__PURE__ */ jsx("nav", {
		className: "academic-breadcrumb",
		"aria-label": "Breadcrumb",
		children: /* @__PURE__ */ jsxs("ol", { children: [/* @__PURE__ */ jsx("li", { children: /* @__PURE__ */ jsx(Link, {
			to: "/",
			children: "Home"
		}) }), /* @__PURE__ */ jsx("li", {
			"aria-current": "page",
			children: name
		})] })
	});
}
function AdmissionsPage() {
	return /* @__PURE__ */ jsxs("div", {
		className: "enquiry-page",
		children: [
			/* @__PURE__ */ jsx("section", {
				className: "admissions-hero",
				children: /* @__PURE__ */ jsxs("div", {
					className: "container",
					children: [
						/* @__PURE__ */ jsx(Breadcrumb, { name: "Admissions" }),
						/* @__PURE__ */ jsx("span", {
							className: "eyebrow",
							children: "A THOUGHTFUL BEGINNING"
						}),
						/* @__PURE__ */ jsxs("h1", { children: [
							"Your next chapter",
							/* @__PURE__ */ jsx("br", {}),
							"starts with a conversation."
						] }),
						/* @__PURE__ */ jsx("p", { children: "Tell us where you are in your learning journey. Let’s discuss the program and next steps that fit your class and goals." }),
						/* @__PURE__ */ jsxs("a", {
							href: "#admission-enquiry",
							className: "button",
							children: ["Start an enquiry ", /* @__PURE__ */ jsx(ArrowRight, { size: 17 })]
						})
					]
				})
			}),
			/* @__PURE__ */ jsx("section", {
				className: "section admission-process",
				children: /* @__PURE__ */ jsxs("div", {
					className: "container",
					children: [
						/* @__PURE__ */ jsx("span", {
							className: "eyebrow",
							children: "HOW TO GET STARTED"
						}),
						/* @__PURE__ */ jsx("h2", { children: "Three simple steps." }),
						/* @__PURE__ */ jsx("ol", { children: [
							["Share your interests", "Choose your class, board and the program you would like to discuss."],
							["Talk to the institute", "Review your enquiry and send it through WhatsApp, or call us directly."],
							["Confirm the next steps", "Ask about suitability, availability, fees and documents before making a decision."]
						].map(([title, copy], index) => /* @__PURE__ */ jsxs("li", { children: [
							/* @__PURE__ */ jsxs("span", { children: ["0", index + 1] }),
							/* @__PURE__ */ jsx("h3", { children: title }),
							/* @__PURE__ */ jsx("p", { children: copy })
						] }, title)) })
					]
				})
			}),
			/* @__PURE__ */ jsx("section", {
				className: "section enquiry-section",
				id: "admission-enquiry",
				children: /* @__PURE__ */ jsxs("div", {
					className: "container enquiry-layout",
					children: [/* @__PURE__ */ jsxs("aside", { children: [
						/* @__PURE__ */ jsx("span", {
							className: "eyebrow",
							children: "ADMISSION ENQUIRY"
						}),
						/* @__PURE__ */ jsxs("h2", { children: [
							"Let’s find",
							/* @__PURE__ */ jsx("br", {}),
							"your starting point."
						] }),
						/* @__PURE__ */ jsx("p", { children: "Enquiries are a first conversation. They do not reserve a seat or confirm admission." }),
						/* @__PURE__ */ jsxs("div", {
							className: "enquiry-aside-note",
							children: [/* @__PURE__ */ jsx("h3", { children: "Before you begin" }), /* @__PURE__ */ jsx("p", { children: "Keep the student’s class, board and program of interest handy. A parent or guardian should make an enquiry for a child." })]
						}),
						/* @__PURE__ */ jsxs("a", {
							className: "enquiry-call",
							href: `tel:+91${institute.phone}`,
							children: [/* @__PURE__ */ jsx(Phone, { size: 18 }), institute.phone]
						}),
						/* @__PURE__ */ jsxs(Link, {
							to: "/counselling",
							className: "text-link",
							children: ["Need help choosing? ", /* @__PURE__ */ jsx(ArrowRight, { size: 16 })]
						})
					] }), /* @__PURE__ */ jsx(EnquiryForm, { kind: "admission" })]
				})
			})
		]
	});
}
function ContactPage() {
	const whatsapp = whatsappUrl("Hello Sri Vidya Classes, I would like to know more about your programs and admissions.");
	const maps = `https://www.google.com/maps/dir/?api=1&destination=${encodeURIComponent(institute.address)}`;
	return /* @__PURE__ */ jsxs("div", {
		className: "enquiry-page",
		children: [
			/* @__PURE__ */ jsx("section", {
				className: "contact-hero",
				children: /* @__PURE__ */ jsxs("div", {
					className: "container",
					children: [/* @__PURE__ */ jsx(Breadcrumb, { name: "Contact" }), /* @__PURE__ */ jsxs("div", { children: [
						/* @__PURE__ */ jsx("span", {
							className: "eyebrow",
							children: "LET’S TALK"
						}),
						/* @__PURE__ */ jsxs("h1", { children: [
							"A question is",
							/* @__PURE__ */ jsx("br", {}),
							"a good place to start."
						] }),
						/* @__PURE__ */ jsx("p", { children: "Speak with Sri Vidya Classes about programs, admission enquiries and your next academic step." })
					] })]
				})
			}),
			/* @__PURE__ */ jsx("section", {
				className: "section",
				children: /* @__PURE__ */ jsxs("div", {
					className: "container contact-options",
					children: [
						/* @__PURE__ */ jsxs("article", { children: [
							/* @__PURE__ */ jsx(Phone, {
								size: 27,
								"aria-hidden": "true"
							}),
							/* @__PURE__ */ jsx("h2", { children: "Call the institute" }),
							/* @__PURE__ */ jsx("a", {
								href: `tel:+91${institute.phone}`,
								children: institute.phone
							}),
							/* @__PURE__ */ jsx("a", {
								href: `tel:+91${institute.secondaryPhone}`,
								children: institute.secondaryPhone
							}),
							/* @__PURE__ */ jsx("p", { children: "Contact numbers supplied by the institute. Please call to confirm current details before visiting." })
						] }),
						/* @__PURE__ */ jsxs("article", { children: [
							/* @__PURE__ */ jsx(MapPin, {
								size: 27,
								"aria-hidden": "true"
							}),
							/* @__PURE__ */ jsx("h2", { children: "Find Sri Vidya" }),
							/* @__PURE__ */ jsx("address", { children: institute.address }),
							/* @__PURE__ */ jsxs("a", {
								className: "text-link",
								href: maps,
								target: "_blank",
								rel: "noopener noreferrer",
								children: ["Get directions ", /* @__PURE__ */ jsx(ArrowRight, { size: 16 })]
							}),
							/* @__PURE__ */ jsx("p", { children: "Directions use the supplied address. Confirm the location with the institute before travelling." })
						] }),
						/* @__PURE__ */ jsxs("article", { children: [
							/* @__PURE__ */ jsx(WhatsAppIcon, { size: 27 }),
							/* @__PURE__ */ jsx("h2", { children: "Continue on WhatsApp" }),
							/* @__PURE__ */ jsx("p", { children: "Use the confirmed WhatsApp number to begin a conversation. You choose when to send." }),
							whatsapp ? /* @__PURE__ */ jsxs("a", {
								className: "text-link",
								href: whatsapp,
								target: "_blank",
								rel: "noopener noreferrer",
								children: ["Open WhatsApp ", /* @__PURE__ */ jsx(ArrowRight, { size: 16 })]
							}) : /* @__PURE__ */ jsx("p", { children: "WhatsApp details are awaiting confirmation." }),
							/* @__PURE__ */ jsxs("div", {
								className: "contact-hours",
								children: [/* @__PURE__ */ jsx(Clock, {
									size: 17,
									"aria-hidden": "true"
								}), /* @__PURE__ */ jsx("span", { children: institute.openingHours || "Please call ahead for visiting hours." })]
							})
						] })
					]
				})
			}),
			/* @__PURE__ */ jsx("section", {
				className: "section enquiry-section",
				id: "contact-enquiry",
				children: /* @__PURE__ */ jsxs("div", {
					className: "container enquiry-layout contact-enquiry-layout",
					children: [/* @__PURE__ */ jsxs("aside", { children: [
						/* @__PURE__ */ jsx("span", {
							className: "eyebrow",
							children: "CONTACT ENQUIRY"
						}),
						/* @__PURE__ */ jsxs("h2", { children: [
							"A little context.",
							/* @__PURE__ */ jsx("br", {}),
							"A better conversation."
						] }),
						/* @__PURE__ */ jsx("p", { children: "Share your question and a contact number. Your message is prepared locally and sent only when you choose Send in WhatsApp." }),
						/* @__PURE__ */ jsxs("div", {
							className: "enquiry-aside-note",
							children: [/* @__PURE__ */ jsx("h3", { children: "Personal information" }), /* @__PURE__ */ jsx("p", { children: "Please include only what we need to answer your question. Avoid identity documents, payment details or medical information." })]
						}),
						/* @__PURE__ */ jsxs(Link, {
							className: "text-link",
							to: "/admissions",
							children: ["Looking for admission? ", /* @__PURE__ */ jsx(ArrowRight, { size: 17 })]
						})
					] }), /* @__PURE__ */ jsx(EnquiryForm, { kind: "contact" })]
				})
			})
		]
	});
}
function CounsellingPage() {
	return /* @__PURE__ */ jsxs("div", {
		className: "enquiry-page",
		children: [/* @__PURE__ */ jsx("section", {
			className: "contact-hero",
			children: /* @__PURE__ */ jsxs("div", {
				className: "container",
				children: [
					/* @__PURE__ */ jsx(Breadcrumb, { name: "Counselling & guidance" }),
					/* @__PURE__ */ jsx("span", {
						className: "eyebrow",
						children: "FIND YOUR DIRECTION"
					}),
					/* @__PURE__ */ jsxs("h1", { children: [
						"Let’s explore",
						/* @__PURE__ */ jsx("br", {}),
						"the right next step."
					] }),
					/* @__PURE__ */ jsx("p", { children: "Questions about a program? Share the student’s class and goals with the institute and ask about a suitable learning pathway." })
				]
			})
		}), /* @__PURE__ */ jsx("section", {
			className: "section",
			children: /* @__PURE__ */ jsxs("div", {
				className: "container guidance-layout",
				children: [/* @__PURE__ */ jsxs("div", { children: [
					/* @__PURE__ */ jsx("h2", { children: "A conversation before a decision." }),
					/* @__PURE__ */ jsx("p", { children: "Consider the student’s current class, board, subjects that need support and academic interests. These are useful starting points when speaking with the institute." }),
					/* @__PURE__ */ jsxs("ul", { children: [
						/* @__PURE__ */ jsx("li", { children: "Which program fits the student’s current learning needs?" }),
						/* @__PURE__ */ jsx("li", { children: "What curriculum and class arrangements apply?" }),
						/* @__PURE__ */ jsx("li", { children: "What information is needed before admission?" })
					] })
				] }), /* @__PURE__ */ jsxs("div", {
					className: "guidance-card",
					children: [
						/* @__PURE__ */ jsx("h3", { children: "Ask about guidance availability" }),
						/* @__PURE__ */ jsx("p", { children: institute.counsellingOffered ? "You can request counselling through the admissions enquiry form. A request is not a confirmed appointment." : "Scheduled counselling and demo classes are not currently confirmed on this website. Please call to ask whether a guidance conversation can be arranged." }),
						/* @__PURE__ */ jsxs(Button, {
							to: "/admissions#admission-enquiry",
							children: ["Prepare an admission enquiry ", /* @__PURE__ */ jsx(ArrowRight, { size: 17 })]
						}),
						/* @__PURE__ */ jsxs("a", {
							className: "enquiry-call",
							href: `tel:+91${institute.phone}`,
							children: [/* @__PURE__ */ jsx(Phone, { size: 18 }), institute.phone]
						})
					]
				})]
			})
		})]
	});
}
function PrivacyPage() {
	return /* @__PURE__ */ jsxs("div", {
		className: "enquiry-page",
		children: [/* @__PURE__ */ jsx("section", {
			className: "contact-hero",
			children: /* @__PURE__ */ jsxs("div", {
				className: "container",
				children: [
					/* @__PURE__ */ jsx(Breadcrumb, { name: "Privacy" }),
					/* @__PURE__ */ jsx("span", {
						className: "eyebrow",
						children: "YOUR ENQUIRY, YOUR CHOICE"
					}),
					/* @__PURE__ */ jsx("h1", { children: "Privacy information." }),
					/* @__PURE__ */ jsx("p", { children: "How the current enquiry forms handle your details." })
				]
			})
		}), /* @__PURE__ */ jsx("section", {
			className: "section",
			children: /* @__PURE__ */ jsxs("div", {
				className: "container privacy-content",
				children: [
					/* @__PURE__ */ jsx("h2", { children: "Drafts stay in your browser tab" }),
					/* @__PURE__ */ jsx("p", { children: "Form drafts are stored in this tab’s session storage for up to 24 hours to preserve your entries across navigation and validation errors. Use Clear draft to remove them, especially on shared devices. If storage is blocked, drafts may not survive navigation. Expired drafts are removed when the form is opened again." }),
					/* @__PURE__ */ jsx("h2", { children: "You decide when to share" }),
					/* @__PURE__ */ jsx("p", { children: "Reviewing a form does not submit it. Continuing to WhatsApp passes your prepared enquiry to WhatsApp using a prefilled link. You must press Send there. WhatsApp handles information according to its own privacy practices. The website cannot confirm message delivery." }),
					/* @__PURE__ */ jsx("h2", { children: "Information requested" }),
					/* @__PURE__ */ jsx("p", { children: "Admission enquiries ask for the student’s name, class, board, program, parent/guardian name and contact number, plus an optional message and consent. Contact enquiries ask for your name, contact number, message and consent. A parent or guardian should enquire on behalf of a child. Do not include identity documents, sensitive personal details or payment information." }),
					/* @__PURE__ */ jsx("h2", { children: "No website delivery service is enabled" }),
					/* @__PURE__ */ jsx("p", { children: "The current website does not send enquiries to a server or email provider and does not log form contents. No analytics provider or advertising integration is enabled. Optional analytics hooks are off by default and require an explicit consent signal; they exclude names, contact numbers, messages, drafts and URL query strings, and respect browser Do Not Track and Global Privacy Control signals. Only the details you choose to share through WhatsApp reach the institute through that service." }),
					/* @__PURE__ */ jsx("h2", { children: "Questions about information you have shared" }),
					/* @__PURE__ */ jsxs("p", { children: [
						"Contact Sri Vidya Classes on ",
						/* @__PURE__ */ jsx("a", {
							href: `tel:+91${institute.phone}`,
							children: institute.phone
						}),
						" about how your enquiry is used, retained or removed after you send it. A complete institute data retention policy has not yet been provided."
					] })
				]
			})
		})]
	});
}
// src/pages/ShowcasePages.tsx
function ShowcaseHero({ gallery = false }) {
	return /* @__PURE__ */ jsx("section", {
		className: `showcase-hero ${gallery ? "showcase-hero-gallery" : ""}`,
		children: /* @__PURE__ */ jsxs("div", {
			className: "container",
			children: [/* @__PURE__ */ jsx("nav", {
				className: "academic-breadcrumb",
				"aria-label": "Breadcrumb",
				children: /* @__PURE__ */ jsxs("ol", { children: [/* @__PURE__ */ jsx("li", { children: /* @__PURE__ */ jsx(Link, {
					to: "/",
					children: "Home"
				}) }), /* @__PURE__ */ jsx("li", {
					"aria-current": "page",
					children: gallery ? "Gallery" : "Results & Achievements"
				})] })
			}), /* @__PURE__ */ jsxs("div", {
				className: "showcase-hero-grid",
				children: [/* @__PURE__ */ jsxs("div", { children: [
					/* @__PURE__ */ jsx("span", {
						className: "eyebrow",
						children: gallery ? "INSIDE SRI VIDYA" : "PROGRESS, WITH PERSPECTIVE"
					}),
					/* @__PURE__ */ jsx("h1", { children: gallery ? /* @__PURE__ */ jsxs(Fragment, { children: [
						"The moments behind",
						/* @__PURE__ */ jsx("br", {}),
						"the learning."
					] }) : /* @__PURE__ */ jsxs(Fragment, { children: [
						"Every achievement.",
						/* @__PURE__ */ jsx("br", {}),
						"An accurate story."
					] }) }),
					/* @__PURE__ */ jsx("p", { children: gallery ? "Explore real classroom moments, activities and events at Sri Vidya Classes. Every photograph shared here belongs to the institute’s story." : "A space for genuine student achievements, shared with permission and clear context. Only verified, approved records appear here." })
				] }), /* @__PURE__ */ jsxs("div", {
					className: "showcase-hero-symbol",
					"aria-hidden": "true",
					children: [gallery ? /* @__PURE__ */ jsx(Image, {
						size: 80,
						strokeWidth: 1
					}) : /* @__PURE__ */ jsx(Trophy, {
						size: 80,
						strokeWidth: 1
					}), /* @__PURE__ */ jsx("span", { children: gallery ? "A REAL LOOK INSIDE" : "CLARITY. EFFORT. PROGRESS." })]
				})]
			})]
		})
	});
}
function ShowcaseContact() {
	return /* @__PURE__ */ jsx("section", {
		className: "showcase-contact",
		children: /* @__PURE__ */ jsxs("div", {
			className: "container",
			children: [
				/* @__PURE__ */ jsxs("div", { children: [
					/* @__PURE__ */ jsx("span", {
						className: "eyebrow",
						children: "LET’S START A CONVERSATION"
					}),
					/* @__PURE__ */ jsx("h2", { children: "Get to know Sri Vidya Classes." }),
					/* @__PURE__ */ jsx("p", { children: "Ask about our programs, learning environment and admissions." })
				] }),
				/* @__PURE__ */ jsxs(Button, {
					to: "/contact",
					children: ["Contact the institute ", /* @__PURE__ */ jsx(ArrowRight, { size: 17 })]
				}),
				/* @__PURE__ */ jsxs("a", {
					href: `tel:+91${institute.phone}`,
					children: [/* @__PURE__ */ jsx(Phone, { size: 16 }), institute.phone]
				})
			]
		})
	});
}
function ResultsPage({ records = achievements }) {
	const approved = publishableAchievements(records);
	const categories = resultCategories.filter((category) => approved.some((record) => record.category === category));
	const [selected, setSelected] = useState("All");
	const active = selected === "All" || categories.includes(selected) ? selected : "All";
	const filtered = approved.filter((record) => active === "All" || record.category === active);
	return /* @__PURE__ */ jsxs("div", {
		className: "showcase-page",
		children: [
			/* @__PURE__ */ jsx(ShowcaseHero, {}),
			/* @__PURE__ */ jsx("section", {
				className: "section",
				children: /* @__PURE__ */ jsxs("div", {
					className: "container",
					children: [
						/* @__PURE__ */ jsxs("div", {
							className: "showcase-section-top",
							children: [/* @__PURE__ */ jsxs("div", { children: [/* @__PURE__ */ jsx("span", {
								className: "eyebrow",
								children: "RESULTS & ACHIEVEMENTS"
							}), /* @__PURE__ */ jsx("h2", { children: "Effort deserves recognition." })] }), /* @__PURE__ */ jsx("p", { children: "Context matters. Coaching results and achievements associated with other institutions are labelled separately." })]
						}),
						approved.length > 0 && /* @__PURE__ */ jsxs(Fragment, { children: [/* @__PURE__ */ jsx("div", {
							className: "showcase-filters",
							role: "group",
							"aria-label": "Filter results",
							children: ["All", ...categories].map((category) => /* @__PURE__ */ jsxs("button", {
								"aria-pressed": active === category,
								onClick: () => setSelected(category),
								children: [category, /* @__PURE__ */ jsx("span", { children: category === "All" ? approved.length : approved.filter((record) => record.category === category).length })]
							}, category))
						}), /* @__PURE__ */ jsxs("p", {
							className: "showcase-count",
							role: "status",
							"aria-live": "polite",
							children: [
								filtered.length,
								" ",
								filtered.length === 1 ? "achievement" : "achievements",
								" · ",
								active
							]
						})] }),
						filtered.length ? /* @__PURE__ */ jsx("div", {
							className: "achievement-grid",
							children: filtered.map((record) => /* @__PURE__ */ jsxs("article", {
								className: "achievement-card",
								children: [/* @__PURE__ */ jsxs("div", {
									className: "achievement-photo",
									children: [/* @__PURE__ */ jsx(ResponsiveImage, {
										src: record.photo.src,
										srcSet: record.photo.srcSet,
										width: record.photo.width,
										height: record.photo.height,
										alt: record.photo.alt,
										sizes: "(max-width: 700px) 100vw, (max-width: 1050px) 50vw, 33vw"
									}), /* @__PURE__ */ jsxs("span", { children: [
										record.category,
										" · ",
										record.year
									] })]
								}), /* @__PURE__ */ jsxs("div", {
									className: "achievement-body",
									children: [
										/* @__PURE__ */ jsx("span", {
											className: `achievement-context ${record.context === "external-achievement" ? "external-context" : ""}`,
											children: record.context === "sri-vidya-coaching" ? "Sri Vidya coaching result" : "External institution achievement"
										}),
										/* @__PURE__ */ jsx("h3", { children: record.studentName }),
										/* @__PURE__ */ jsxs("p", {
											className: "achievement-exam",
											children: [
												record.exam,
												" · ",
												record.year
											]
										}),
										/* @__PURE__ */ jsx("strong", {
											className: "achievement-result",
											children: record.result
										}),
										/* @__PURE__ */ jsx("p", { children: record.description }),
										record.context === "external-achievement" && /* @__PURE__ */ jsxs("p", {
											className: "achievement-disclosure",
											children: [
												"Associated institution: ",
												/* @__PURE__ */ jsx("strong", { children: record.institutionName }),
												". This is not presented as a Sri Vidya coaching result."
											]
										})
									]
								})]
							}, record.id))
						}) : /* @__PURE__ */ jsxs("div", {
							className: "showcase-empty",
							children: [
								/* @__PURE__ */ jsx("span", {
									className: "empty-symbol",
									children: /* @__PURE__ */ jsx(Trophy, {
										size: 42,
										strokeWidth: 1.2,
										"aria-hidden": "true"
									})
								}),
								/* @__PURE__ */ jsx("span", {
									className: "eyebrow",
									children: "VERIFICATION BEFORE PUBLICATION"
								}),
								/* @__PURE__ */ jsx("h3", { children: "Good stories deserve the right details." }),
								/* @__PURE__ */ jsx("p", { children: "Verified student results and approved photographs are not yet available. We’ll share achievements here once the records and publication permissions are confirmed." }),
								/* @__PURE__ */ jsxs("div", {
									className: "actions",
									children: [/* @__PURE__ */ jsxs(Button, {
										to: "/programs",
										children: ["Explore our programs ", /* @__PURE__ */ jsx(ArrowRight, { size: 17 })]
									}), /* @__PURE__ */ jsx(Button, {
										to: "/contact",
										secondary: true,
										children: "Ask the institute"
									})]
								})
							]
						}),
						/* @__PURE__ */ jsxs("div", {
							className: "showcase-editorial-note",
							children: [/* @__PURE__ */ jsx(Trophy, {
								size: 23,
								"aria-hidden": "true"
							}), /* @__PURE__ */ jsx("p", { children: "A result belongs to its specific exam, year and student. An admission offer or an achievement at another institution is not a coaching result or a guarantee of future performance." })]
						})
					]
				})
			}),
			/* @__PURE__ */ jsx(ShowcaseContact, {})
		]
	});
}
function GalleryPage({ photos = galleryPhotos }) {
	const approved = publishableGallery(photos);
	const [selected, setSelected] = useState("All");
	const [activeId, setActiveId] = useState(null);
	const filtered = approved.filter((photo) => selected === "All" || photo.category === selected);
	const active = filtered.findIndex((photo) => photo.id === activeId);
	return /* @__PURE__ */ jsxs("div", {
		className: "showcase-page",
		children: [
			/* @__PURE__ */ jsx(ShowcaseHero, { gallery: true }),
			/* @__PURE__ */ jsx("section", {
				className: "section",
				children: /* @__PURE__ */ jsxs("div", {
					className: "container",
					children: [
						/* @__PURE__ */ jsxs("div", {
							className: "showcase-section-top",
							children: [/* @__PURE__ */ jsxs("div", { children: [/* @__PURE__ */ jsx("span", {
								className: "eyebrow",
								children: "THE SRI VIDYA EXPERIENCE"
							}), /* @__PURE__ */ jsx("h2", { children: "A window into everyday learning." })] }), /* @__PURE__ */ jsx("p", { children: "Classroom, activities, events and achievements — through real, approved institute photographs." })]
						}),
						/* @__PURE__ */ jsx("div", {
							className: "showcase-filters",
							role: "group",
							"aria-label": "Filter gallery",
							children: ["All", ...galleryCategories].map((category) => /* @__PURE__ */ jsxs("button", {
								"aria-pressed": selected === category,
								onClick: () => {
									setActiveId(null);
									setSelected(category);
								},
								children: [category, /* @__PURE__ */ jsx("span", { children: category === "All" ? approved.length : approved.filter((photo) => photo.category === category).length })]
							}, category))
						}),
						/* @__PURE__ */ jsxs("p", {
							className: "showcase-count",
							role: "status",
							"aria-live": "polite",
							children: [
								filtered.length,
								" ",
								filtered.length === 1 ? "photograph" : "photographs",
								" · ",
								selected
							]
						}),
						filtered.length ? /* @__PURE__ */ jsx("div", {
							className: "editorial-gallery",
							children: filtered.map((photo) => /* @__PURE__ */ jsxs("figure", { children: [/* @__PURE__ */ jsxs("button", {
								className: "gallery-photo-button",
								"aria-label": `View photo: ${photo.caption}`,
								"aria-haspopup": "dialog",
								onClick: () => setActiveId(photo.id),
								children: [/* @__PURE__ */ jsx(ResponsiveImage, {
									src: photo.src,
									srcSet: photo.srcSet,
									width: photo.width,
									height: photo.height,
									alt: photo.alt,
									sizes: "(max-width: 700px) 100vw, (max-width: 1050px) 50vw, 33vw"
								}), /* @__PURE__ */ jsx("span", {
									className: "photo-open",
									children: /* @__PURE__ */ jsx(Maximize2, {
										size: 18,
										"aria-hidden": "true"
									})
								})]
							}), /* @__PURE__ */ jsxs("figcaption", { children: [/* @__PURE__ */ jsx("span", { children: photo.category }), /* @__PURE__ */ jsx("h3", { children: photo.caption })] })] }, photo.id))
						}) : /* @__PURE__ */ jsxs("div", {
							className: "showcase-empty gallery-empty",
							children: [
								/* @__PURE__ */ jsx("span", {
									className: "empty-symbol",
									children: /* @__PURE__ */ jsx(Image, {
										size: 42,
										strokeWidth: 1.2,
										"aria-hidden": "true"
									})
								}),
								/* @__PURE__ */ jsx("span", {
									className: "eyebrow",
									children: "REAL MOMENTS, SHARED WITH CARE"
								}),
								/* @__PURE__ */ jsx("h3", { children: approved.length ? `No ${selected.toLowerCase()} photographs yet.` : "A real look inside. Coming soon." }),
								/* @__PURE__ */ jsx("p", { children: approved.length ? "Choose another category to explore the available institute photographs." : "Approved institute photographs will appear here once they are supplied and publication permissions are confirmed." }),
								selected !== "All" ? /* @__PURE__ */ jsxs("button", {
									className: "button",
									onClick: () => setSelected("All"),
									children: ["View all photographs ", /* @__PURE__ */ jsx(ArrowRight, { size: 17 })]
								}) : /* @__PURE__ */ jsxs(Button, {
									to: "/about",
									secondary: true,
									children: ["Get to know Sri Vidya ", /* @__PURE__ */ jsx(ArrowRight, { size: 17 })]
								})
							]
						})
					]
				})
			}),
			/* @__PURE__ */ jsx(ShowcaseContact, {}),
			active >= 0 && /* @__PURE__ */ jsx(GalleryLightbox, {
				photos: filtered,
				initialIndex: active,
				onClose: () => setActiveId(null)
			}, selected)
		]
	});
}
function GalleryLightbox({ photos, initialIndex, onClose }) {
	const [index, setIndex] = useState(initialIndex);
	const dialog = useRef(null);
	const touch = useRef(null);
	const photo = photos[index];
	const move = (delta) => setIndex((current) => (current + delta + photos.length) % photos.length);
	useEffect(() => {
		const opener = document.activeElement;
		const overflow = document.body.style.overflow;
		const modal = dialog.current;
		modal?.showModal();
		document.body.style.overflow = "hidden";
		return () => {
			modal?.close();
			document.body.style.overflow = overflow;
			if (opener?.isConnected) opener.focus();
		};
	}, []);
	const onTouchEnd = (event) => {
		if (!touch.current || event.changedTouches.length !== 1 || event.touches.length) {
			touch.current = null;
			return;
		}
		const dx = event.changedTouches[0].clientX - touch.current.x;
		const dy = event.changedTouches[0].clientY - touch.current.y;
		if (Math.abs(dx) > 60 && Math.abs(dx) > Math.abs(dy) * 1.5 && photos.length > 1) move(dx < 0 ? 1 : -1);
		touch.current = null;
	};
	return /* @__PURE__ */ jsx("dialog", {
		ref: dialog,
		className: "gallery-lightbox",
		"aria-labelledby": "lightbox-caption",
		onCancel: (event) => {
			event.preventDefault();
			onClose();
		},
		onClick: (event) => {
			if (event.target === event.currentTarget) onClose();
		},
		onKeyDown: (event) => {
			if (event.key === "ArrowRight") {
				event.preventDefault();
				move(1);
			}
			if (event.key === "ArrowLeft") {
				event.preventDefault();
				move(-1);
			}
			if (event.key === "Tab") {
				const controls = Array.from(event.currentTarget.querySelectorAll("button:not([disabled])"));
				const first = controls[0], last = controls[controls.length - 1];
				if (event.shiftKey && document.activeElement === first) {
					event.preventDefault();
					last?.focus();
				} else if (!event.shiftKey && document.activeElement === last) {
					event.preventDefault();
					first?.focus();
				}
			}
		},
		children: /* @__PURE__ */ jsxs("div", {
			className: "lightbox-shell",
			children: [
				/* @__PURE__ */ jsxs("div", {
					className: "lightbox-toolbar",
					children: [/* @__PURE__ */ jsxs("span", {
						role: "status",
						"aria-live": "polite",
						children: [
							index + 1,
							" / ",
							photos.length,
							" · ",
							photo.category
						]
					}), /* @__PURE__ */ jsx("button", {
						className: "lightbox-control",
						autoFocus: true,
						"aria-label": "Close photo viewer",
						onClick: onClose,
						children: /* @__PURE__ */ jsx(X, {})
					})]
				}),
				/* @__PURE__ */ jsx("div", {
					className: "lightbox-image",
					onTouchStart: (event) => {
						touch.current = event.touches.length === 1 ? {
							x: event.touches[0].clientX,
							y: event.touches[0].clientY
						} : null;
					},
					onTouchEnd,
					onTouchCancel: () => {
						touch.current = null;
					},
					children: /* @__PURE__ */ jsx("img", {
						src: photo.src,
						srcSet: photo.srcSet,
						sizes: "(max-width: 1000px) 94vw, 1100px",
						width: photo.width,
						height: photo.height,
						alt: photo.alt,
						decoding: "async"
					})
				}),
				/* @__PURE__ */ jsxs("div", {
					className: "lightbox-bottom",
					children: [
						/* @__PURE__ */ jsx("button", {
							className: "lightbox-control",
							disabled: photos.length < 2,
							"aria-label": "Previous photo",
							onClick: () => move(-1),
							children: /* @__PURE__ */ jsx(ArrowLeft, {})
						}),
						/* @__PURE__ */ jsxs("div", { children: [/* @__PURE__ */ jsx("h2", {
							id: "lightbox-caption",
							children: photo.caption
						}), /* @__PURE__ */ jsx("p", { children: "Use arrow keys or swipe to explore. Escape closes the viewer." })] }),
						/* @__PURE__ */ jsx("button", {
							className: "lightbox-control",
							disabled: photos.length < 2,
							"aria-label": "Next photo",
							onClick: () => move(1),
							children: /* @__PURE__ */ jsx(ArrowRight, {})
						})
					]
				})
			]
		})
	});
}
// src/components/SiteMotion.tsx
function AcademicLoader() {
	const [pending, setPending] = useState(true);
	useEffect(() => {
		let active = true;
		const images = Array.from(document.querySelectorAll("img[loading=\"eager\"]"));
		const resources = [document.fonts.ready, ...images.map((image) => image.decode().catch(() => void 0))];
		Promise.allSettled(resources).then(() => {
			if (active) setPending(false);
		});
		return () => {
			active = false;
		};
	}, []);
	if (!pending) return null;
	return /* @__PURE__ */ jsxs("div", {
		className: "academic-loader",
		"aria-hidden": "true",
		children: [
			/* @__PURE__ */ jsx("span", {
				className: "loader-book",
				children: /* @__PURE__ */ jsx(BookOpen, {
					size: 32,
					strokeWidth: 1.5
				})
			}),
			/* @__PURE__ */ jsx("span", {
				className: "loader-symbols",
				children: "∑ \xA0 π \xA0 C—C"
			}),
			/* @__PURE__ */ jsxs("span", {
				className: "loader-brand",
				children: [
					"Sri Vidya ",
					/* @__PURE__ */ jsx("strong", { children: "Classes" }),
					/* @__PURE__ */ jsx("small", { children: "LEARNING WITH PURPOSE" })
				]
			})
		]
	});
}
function ScrollProgress() {
	const bar = useRef(null);
	const { pathname } = useLocation();
	useEffect(() => {
		let frame = 0;
		const update = () => {
			frame = 0;
			const maximum = document.documentElement.scrollHeight - window.innerHeight;
			const fraction = maximum > 0 ? Math.min(1, Math.max(0, window.scrollY / maximum)) : 0;
			if (bar.current) bar.current.style.transform = `scaleX(${fraction})`;
		};
		const schedule = () => {
			if (!frame) frame = requestAnimationFrame(update);
		};
		window.addEventListener("scroll", schedule, { passive: true });
		window.addEventListener("resize", schedule);
		const observer = new ResizeObserver(schedule);
		observer.observe(document.body);
		update();
		return () => {
			window.removeEventListener("scroll", schedule);
			window.removeEventListener("resize", schedule);
			observer.disconnect();
			if (frame) cancelAnimationFrame(frame);
		};
	}, [pathname]);
	return /* @__PURE__ */ jsx("div", {
		ref: bar,
		className: "scroll-progress",
		"aria-hidden": "true"
	});
}
// src/components/Header.tsx
var navigation = [
	["/", "Home"],
	["/about", "About"],
	["/programs", "Programs"],
	["/faculty", "Faculty"],
	["/results", "Results"],
	["/gallery", "Gallery"],
	["/learning-hub", "Learning Hub"],
	["/contact", "Contact"]
];
function Brand() {
	return /* @__PURE__ */ jsxs(Link, {
		to: "/",
		className: "brand",
		"aria-label": `${institute.name} home`,
		children: [institute.logo && /* @__PURE__ */ jsx("img", {
			src: institute.logo,
			alt: "Sri Vidya Classes crest",
			width: 64,
			height: 64
		}), /* @__PURE__ */ jsxs("span", { children: [
			"Sri Vidya ",
			/* @__PURE__ */ jsx("strong", { children: "Classes" }),
			/* @__PURE__ */ jsx("small", { children: "LEARNING WITH PURPOSE" })
		] })]
	});
}
function Header() {
	const drawer = useRef(null);
	const trigger = useRef(null);
	const previousOverflow = useRef("");
	const open = () => {
		if (!drawer.current || drawer.current.open) return;
		previousOverflow.current = document.body.style.overflow;
		drawer.current.showModal();
		document.body.style.overflow = "hidden";
	};
	const close = () => drawer.current?.close();
	useEffect(() => {
		const media = window.matchMedia("(min-width: 1200px)");
		const onChange = () => {
			if (media.matches) drawer.current?.close();
		};
		media.addEventListener("change", onChange);
		return () => media.removeEventListener("change", onChange);
	}, []);
	const links = () => navigation.map(([to, name]) => /* @__PURE__ */ jsx(NavLink, {
		caseSensitive: true,
		end: to === "/",
		to,
		onClick: close,
		children: name
	}, to));
	return /* @__PURE__ */ jsxs("header", {
		className: "site-header",
		children: [/* @__PURE__ */ jsxs("div", {
			className: "container header-inner",
			children: [
				/* @__PURE__ */ jsx(Brand, {}),
				/* @__PURE__ */ jsx("nav", {
					className: "desktop-nav",
					"aria-label": "Main navigation",
					children: links()
				}),
				/* @__PURE__ */ jsxs("div", {
					className: "header-contact",
					children: [/* @__PURE__ */ jsxs("a", {
						className: "header-phone",
						href: `tel:+91${institute.phone}`,
						children: [/* @__PURE__ */ jsx(Phone, {
							size: 15,
							"aria-hidden": "true"
						}), institute.phone]
					}), /* @__PURE__ */ jsxs(Link, {
						className: "nav-cta",
						to: "/admissions",
						children: ["Admission Enquiry ", /* @__PURE__ */ jsx(ArrowUpRight, {
							size: 15,
							"aria-hidden": "true"
						})]
					})]
				}),
				/* @__PURE__ */ jsx("button", {
					ref: trigger,
					className: "menu-toggle",
					"aria-label": "Open navigation",
					"aria-haspopup": "dialog",
					onClick: open,
					children: /* @__PURE__ */ jsx(Menu, {})
				})
			]
		}), /* @__PURE__ */ jsx("dialog", {
			ref: drawer,
			className: "mobile-drawer",
			"aria-labelledby": "drawer-title",
			onClose: () => {
				document.body.style.overflow = previousOverflow.current;
				trigger.current?.focus();
			},
			onKeyDown: (e) => {
				if (e.key !== "Tab") return;
				const items = Array.from(e.currentTarget.querySelectorAll("a[href], button:not([disabled])"));
				const first = items[0], last = items[items.length - 1];
				if (e.shiftKey && document.activeElement === first) {
					e.preventDefault();
					last?.focus();
				} else if (!e.shiftKey && document.activeElement === last) {
					e.preventDefault();
					first?.focus();
				}
			},
			onClick: (e) => {
				if (e.target === e.currentTarget) close();
			},
			children: /* @__PURE__ */ jsxs("div", {
				className: "drawer-content",
				children: [
					/* @__PURE__ */ jsxs("div", {
						className: "drawer-top",
						children: [/* @__PURE__ */ jsx("span", {
							id: "drawer-title",
							children: "Sri Vidya Classes"
						}), /* @__PURE__ */ jsx("button", {
							"aria-label": "Close navigation",
							autoFocus: true,
							onClick: close,
							children: /* @__PURE__ */ jsx(X, {})
						})]
					}),
					/* @__PURE__ */ jsx("p", {
						className: "drawer-label",
						children: "EXPLORE SRI VIDYA"
					}),
					/* @__PURE__ */ jsx("nav", {
						"aria-label": "Mobile navigation",
						children: links()
					}),
					/* @__PURE__ */ jsxs("div", {
						className: "drawer-bottom",
						children: [/* @__PURE__ */ jsxs("a", {
							className: "header-phone",
							href: `tel:+91${institute.phone}`,
							children: [/* @__PURE__ */ jsx(Phone, {
								size: 17,
								"aria-hidden": "true"
							}), institute.phone]
						}), /* @__PURE__ */ jsxs(Link, {
							className: "nav-cta",
							to: "/admissions",
							onClick: close,
							children: ["Admission Enquiry ", /* @__PURE__ */ jsx(ArrowUpRight, { size: 16 })]
						})]
					})
				]
			})
		})]
	});
}
// src/components/ContactControls.tsx
function ContactControls() {
	const whatsapp = whatsappUrl("Hello Sri Vidya Classes, I would like to enquire about your programs and admissions.");
	return /* @__PURE__ */ jsxs("div", {
		className: "contact-controls",
		role: "group",
		"aria-label": "Quick contact controls",
		children: [
			whatsapp ? /* @__PURE__ */ jsxs("a", {
				href: whatsapp,
				target: "_blank",
				rel: "noopener noreferrer",
				className: "quick-whatsapp",
				"aria-label": "Open Sri Vidya Classes WhatsApp; press Send in WhatsApp",
				children: [/* @__PURE__ */ jsx(WhatsAppIcon, { size: 23 }), /* @__PURE__ */ jsx("span", { children: "WhatsApp" })]
			}) : /* @__PURE__ */ jsxs("a", {
				href: "/contact#contact-enquiry",
				className: "quick-whatsapp",
				children: [/* @__PURE__ */ jsx(MessageCircle, { size: 21 }), /* @__PURE__ */ jsx("span", { children: "Contact" })]
			}),
			/* @__PURE__ */ jsxs("a", {
				className: "quick-call",
				href: `tel:+91${institute.phone}`,
				"aria-label": `Call Sri Vidya Classes on ${institute.phone}`,
				children: [/* @__PURE__ */ jsx(Phone, {
					size: 20,
					"aria-hidden": "true"
				}), /* @__PURE__ */ jsx("span", { children: "Call" })]
			}),
			/* @__PURE__ */ jsxs("button", {
				type: "button",
				"aria-label": "Back to top",
				onClick: () => {
					window.scrollTo({
						top: 0,
						behavior: window.matchMedia("(prefers-reduced-motion: reduce)").matches ? "instant" : "smooth"
					});
					document.getElementById("page-top")?.focus({ preventScroll: true });
				},
				children: [/* @__PURE__ */ jsx(ArrowUp, {
					size: 20,
					"aria-hidden": "true"
				}), /* @__PURE__ */ jsx("span", { children: "Top" })]
			})
		]
	});
}
// src/components/Layout.tsx
function Layout() {
	const { pathname, hash } = useLocation();
	useEffect(() => {
		if (hash) {
			requestAnimationFrame(() => document.getElementById(hash.slice(1))?.scrollIntoView());
			return;
		}
		window.scrollTo(0, 0);
		if (pathname !== "/") document.getElementById("main-content")?.focus();
	}, [pathname, hash]);
	return /* @__PURE__ */ jsxs(Fragment, { children: [
		/* @__PURE__ */ jsx("a", {
			className: "skip-link",
			href: "#main-content",
			children: "Skip to content"
		}),
		/* @__PURE__ */ jsx("div", {
			id: "page-top",
			tabIndex: -1
		}),
		/* @__PURE__ */ jsx(ScrollProgress, {}),
		/* @__PURE__ */ jsx(AcademicLoader, {}),
		/* @__PURE__ */ jsx(Header, {}),
		/* @__PURE__ */ jsx("main", {
			id: "main-content",
			tabIndex: -1,
			children: /* @__PURE__ */ jsx(Outlet, {})
		}),
		/* @__PURE__ */ jsxs("footer", { children: [/* @__PURE__ */ jsxs("div", {
			className: "container footer-grid",
			children: [
				/* @__PURE__ */ jsxs("div", { children: [
					/* @__PURE__ */ jsx(Brand, {}),
					/* @__PURE__ */ jsx("p", { children: "A thoughtful beginning to your next chapter." }),
					/* @__PURE__ */ jsx("span", {
						className: "footer-label",
						children: "T. Balu Mahendra"
					})
				] }),
				/* @__PURE__ */ jsxs("div", { children: [
					/* @__PURE__ */ jsx("h2", { children: "Explore" }),
					/* @__PURE__ */ jsx(Link, {
						to: "/about",
						children: "About the institute"
					}),
					/* @__PURE__ */ jsx(Link, {
						to: "/programs",
						children: "Programs"
					}),
					/* @__PURE__ */ jsx(Link, {
						to: "/faculty",
						children: "Meet the faculty"
					})
				] }),
				/* @__PURE__ */ jsxs("div", { children: [
					/* @__PURE__ */ jsx("h2", { children: "Useful links" }),
					/* @__PURE__ */ jsx(Link, {
						to: "/admissions",
						children: "Admissions"
					}),
					/* @__PURE__ */ jsx(Link, {
						to: "/learning-hub",
						children: "Learning Hub"
					}),
					/* @__PURE__ */ jsx(Link, {
						to: "/faqs",
						children: "FAQs"
					}),
					/* @__PURE__ */ jsx(Link, {
						to: "/contact",
						children: "Contact"
					})
				] }),
				/* @__PURE__ */ jsxs("div", { children: [
					/* @__PURE__ */ jsx("h2", { children: "Stay connected" }),
					institute.address && /* @__PURE__ */ jsx("p", { children: institute.address }),
					institute.phone && /* @__PURE__ */ jsx("a", {
						href: `tel:${institute.phone}`,
						children: institute.phone
					}),
					institute.socials.map((s) => /* @__PURE__ */ jsx("a", {
						href: s.url,
						target: "_blank",
						rel: "noopener noreferrer",
						children: s.name
					}, s.name)),
					/* @__PURE__ */ jsx("a", {
						href: `tel:+91${institute.secondaryPhone}`,
						children: institute.secondaryPhone
					}),
					/* @__PURE__ */ jsx("p", { children: "Please call ahead before visiting." })
				] })
			]
		}), /* @__PURE__ */ jsxs("div", {
			className: "container footer-bottom",
			children: [/* @__PURE__ */ jsx("span", { children: "© 2026 K J Tech Solutions. All Rights Reserved." }), /* @__PURE__ */ jsxs("div", { children: [/* @__PURE__ */ jsx(Link, {
				to: "/privacy",
				children: "Privacy"
			}), /* @__PURE__ */ jsx(Link, {
				to: "/terms",
				children: "Terms"
			})] })]
		})] }),
		/* @__PURE__ */ jsx(ContactControls, {})
	] });
}
// src/components/Hero.tsx
function Hero() {
	return /* @__PURE__ */ jsx("section", {
		className: "premium-hero",
		"aria-labelledby": "hero-title",
		children: /* @__PURE__ */ jsxs("div", {
			className: "container premium-hero-grid",
			children: [
				/* @__PURE__ */ jsxs(Motion, {
					className: "hero-message",
					children: [
						/* @__PURE__ */ jsxs("span", {
							className: "eyebrow",
							children: [/* @__PURE__ */ jsx("span", { className: "gold-line" }), "CLARITY IN EVERY CONCEPT"]
						}),
						/* @__PURE__ */ jsxs("h1", {
							id: "hero-title",
							children: [
								"SRI VIDYA",
								/* @__PURE__ */ jsx("br", {}),
								/* @__PURE__ */ jsx("span", { children: "CLASSES." })
							]
						}),
						/* @__PURE__ */ jsxs("p", {
							className: "program-line",
							children: [
								"IIT JEE ",
								/* @__PURE__ */ jsx("span", { children: "|" }),
								" NEET ",
								/* @__PURE__ */ jsx("span", { children: "|" }),
								" FOUNDATION"
							]
						}),
						/* @__PURE__ */ jsx("p", {
							className: "hero-description",
							children: "Build strong concepts for the classroom and beyond. Prepare for academic and competitive exams with understanding at the heart of every step."
						}),
						/* @__PURE__ */ jsxs("div", {
							className: "actions",
							children: [/* @__PURE__ */ jsxs(Button, {
								to: "/admissions",
								children: ["Enquire for Admission ", /* @__PURE__ */ jsx(ArrowRight, {
									size: 17,
									"aria-hidden": "true"
								})]
							}), /* @__PURE__ */ jsx(Button, {
								to: "/programs",
								secondary: true,
								children: "Explore Programs"
							})]
						}),
						/* @__PURE__ */ jsxs("div", {
							className: "hero-note",
							children: [/* @__PURE__ */ jsx(BookOpen, {
								size: 19,
								"aria-hidden": "true"
							}), /* @__PURE__ */ jsx("span", { children: "Concept-based learning. Purposeful preparation." })]
						})
					]
				}),
				/* @__PURE__ */ jsxs(Motion, {
					className: "portrait-stage",
					children: [
						/* @__PURE__ */ jsx("div", {
							className: "portrait-halo",
							"aria-hidden": "true"
						}),
						/* @__PURE__ */ jsx("span", {
							className: "academic-symbol symbol-one",
							"aria-hidden": "true",
							children: "ƒ(x)"
						}),
						/* @__PURE__ */ jsx(Atom, {
							className: "academic-symbol symbol-two",
							size: 32,
							"aria-hidden": "true"
						}),
						/* @__PURE__ */ jsx("span", {
							className: "academic-symbol symbol-three",
							"aria-hidden": "true",
							children: "π"
						}),
						institute.facultyPhoto ? /* @__PURE__ */ jsx(ResponsiveImage, {
							className: "teacher-portrait",
							src: institute.facultyPhoto,
							srcSet: institute.facultyPhotoSrcSet,
							sizes: "(max-width: 700px) 320px, (max-width: 1199px) 45vw, 400px",
							alt: "T. Balu Mahendra sir",
							width: 1086,
							height: 1448,
							loading: "eager",
							fetchPriority: "high"
						}) : /* @__PURE__ */ jsxs("div", {
							className: "portrait-pending",
							children: [/* @__PURE__ */ jsx(BookOpen, {
								size: 44,
								strokeWidth: 1,
								"aria-hidden": "true"
							}), /* @__PURE__ */ jsxs("p", { children: [
								"Approved faculty portrait",
								/* @__PURE__ */ jsx("br", {}),
								"to be added"
							] })]
						}),
						/* @__PURE__ */ jsxs("div", {
							className: "portrait-name",
							children: [
								/* @__PURE__ */ jsx("span", { children: "MEET YOUR FACULTY" }),
								/* @__PURE__ */ jsxs("h2", { children: ["T. Balu Mahendra ", /* @__PURE__ */ jsx("small", { children: "sir" })] }),
								/* @__PURE__ */ jsxs(Link, {
									to: "/faculty",
									children: ["Get to know sir ", /* @__PURE__ */ jsx(ArrowRight, { size: 14 })]
								})
							]
						})
					]
				}),
				/* @__PURE__ */ jsxs(Motion, {
					className: "program-panel",
					children: [
						/* @__PURE__ */ jsxs("div", {
							className: "panel-heading",
							children: [/* @__PURE__ */ jsx(GraduationCap, {
								size: 24,
								strokeWidth: 1.5,
								"aria-hidden": "true"
							}), /* @__PURE__ */ jsx("span", { children: "YOUR PATH FORWARD" })]
						}),
						/* @__PURE__ */ jsxs("h2", { children: [
							"One foundation.",
							/* @__PURE__ */ jsx("br", {}),
							"New possibilities."
						] }),
						/* @__PURE__ */ jsxs("ul", { children: [
							/* @__PURE__ */ jsxs("li", { children: [/* @__PURE__ */ jsx("span", { children: "01" }), /* @__PURE__ */ jsxs("div", { children: [/* @__PURE__ */ jsx("h3", { children: "IIT JEE" }), /* @__PURE__ */ jsx("p", { children: "Engineering entrance preparation" })] })] }),
							/* @__PURE__ */ jsxs("li", { children: [/* @__PURE__ */ jsx("span", { children: "02" }), /* @__PURE__ */ jsxs("div", { children: [/* @__PURE__ */ jsx("h3", { children: "NEET" }), /* @__PURE__ */ jsx("p", { children: "Medical entrance preparation" })] })] }),
							/* @__PURE__ */ jsxs("li", { children: [/* @__PURE__ */ jsx("span", { children: "03" }), /* @__PURE__ */ jsxs("div", { children: [/* @__PURE__ */ jsx("h3", { children: "FOUNDATION" }), /* @__PURE__ */ jsx("p", { children: "Build academic fundamentals" })] })] })
						] }),
						/* @__PURE__ */ jsxs(Link, {
							to: "/programs",
							children: ["Explore programs ", /* @__PURE__ */ jsx(ArrowRight, { size: 16 })]
						})
					]
				})
			]
		})
	});
}
// src/config/homepage.ts
var signaturePrograms = programs;
var homepage = {
	classroomPhoto: "",
	classroomPhotoAlt: "T. Balu Mahendra teaching at Sri Vidya Classes",
	gallery: publishableGallery(galleryPhotos),
	results: publishableAchievements(achievements).filter((record) => record.context === "sri-vidya-coaching").map((record) => ({
		title: record.studentName + " · " + record.exam + " · " + record.year,
		detail: record.result + " — " + record.description
	})),
	testimonials: []
};
var faqs = [
	{
		question: "Which programs can I enquire about?",
		answer: "You can enquire about Classes 4–10 School Academics/Foundation, Classes 11–12 Board + JEE + NEET, and Organic Chemistry Mentorship. Contact the institute to confirm availability and the right fit."
	},
	{
		question: "How do I enquire about admission?",
		answer: "Call 9959010394 to speak with Sri Vidya Classes. Share the student’s class and the program you are interested in, and ask about the next steps."
	},
	{
		question: "Where can I find fees and class timings?",
		answer: "Please contact the institute for confirmed fees, batch timings and admission requirements. These details are not yet published on this website."
	},
	{
		question: "Are verified student results available?",
		answer: "Approved result records are not yet available on the website. Results and achievements will be added after verification."
	}
];
// src/pages/Home.tsx
var strengths = [
	["Concept clarity", "Start with the why, so each idea has meaning beyond a memorised answer."],
	["Regular tests", "Use assessment to identify understanding and the areas that need another look."],
	["Purposeful practice", "Work through questions to connect concepts with their application."],
	["Academic foundations", "Strengthen the fundamentals that support the next stage of learning."],
	["Personal attention", "Make space for questions, individual doubts and the next step forward."]
];
var steps = [
	[
		"Understand",
		"Explore the concept. Ask why it works.",
		BookOpen
	],
	[
		"Practice",
		"Apply the idea through focused questions.",
		Layers
	],
	[
		"Assess",
		"Check understanding and recognise gaps.",
		ClipboardCheck
	],
	[
		"Improve",
		"Revisit, refine and build on what you know.",
		Sprout
	]
];
function Home() {
	const revealRoot = useHomepageReveals();
	const spotlight = homepage.classroomPhoto || institute.facultyPhoto;
	return /* @__PURE__ */ jsxs(Fragment, { children: [/* @__PURE__ */ jsx(Hero, {}), /* @__PURE__ */ jsxs("div", {
		className: "homepage-content",
		ref: revealRoot,
		children: [
			/* @__PURE__ */ jsx("section", {
				className: "section signature-section",
				"aria-labelledby": "programs-title",
				children: /* @__PURE__ */ jsxs("div", {
					className: "container",
					"data-reveal-group": true,
					children: [/* @__PURE__ */ jsxs("div", {
						className: "section-top",
						"data-reveal": true,
						children: [/* @__PURE__ */ jsxs("div", { children: [
							/* @__PURE__ */ jsx("span", {
								className: "eyebrow",
								children: "A PATH FOR EVERY STAGE"
							}),
							/* @__PURE__ */ jsx("h2", {
								id: "programs-title",
								className: "home-heading",
								children: "Strong beginnings. Focused preparation."
							}),
							/* @__PURE__ */ jsx("p", { children: "From school fundamentals to the subjects that shape your next chapter." })
						] }), /* @__PURE__ */ jsxs(Link, {
							className: "text-link",
							to: "/programs",
							children: ["All programs ", /* @__PURE__ */ jsx(ArrowRight, { size: 17 })]
						})]
					}), /* @__PURE__ */ jsx("div", {
						className: "signature-grid",
						children: signaturePrograms.map((program, index) => /* @__PURE__ */ jsxs("article", {
							className: `signature-card signature-${index}`,
							"data-reveal": true,
							children: [
								/* @__PURE__ */ jsxs("div", {
									className: "signature-card-top",
									children: [/* @__PURE__ */ jsx("span", { children: program.label }), /* @__PURE__ */ jsxs("span", { children: ["0", index + 1] })]
								}),
								index === 2 ? /* @__PURE__ */ jsx("span", {
									className: "chemistry-motif",
									"aria-hidden": "true",
									children: "C — C"
								}) : /* @__PURE__ */ jsx(GraduationCap, {
									className: "program-icon",
									size: 36,
									strokeWidth: 1.3,
									"aria-hidden": "true"
								}),
								/* @__PURE__ */ jsx("h3", { children: program.name }),
								/* @__PURE__ */ jsx("p", { children: program.description }),
								/* @__PURE__ */ jsx("span", {
									className: "program-focus",
									children: program.focus
								}),
								/* @__PURE__ */ jsxs(Link, {
									to: `/programs/${program.slug}`,
									children: ["Explore program ", /* @__PURE__ */ jsx(ArrowRight, { size: 18 })]
								})
							]
						}, program.slug))
					})]
				})
			}),
			/* @__PURE__ */ jsx("section", {
				className: "section spotlight-section",
				"aria-labelledby": "about-title",
				children: /* @__PURE__ */ jsxs("div", {
					className: "container spotlight-grid",
					"data-reveal-group": true,
					children: [/* @__PURE__ */ jsxs("div", {
						className: `spotlight-media ${!homepage.classroomPhoto ? "spotlight-portrait" : ""}`,
						"data-reveal": true,
						children: [spotlight ? /* @__PURE__ */ jsx(ResponsiveImage, {
							src: spotlight,
							srcSet: !homepage.classroomPhoto ? institute.facultyPhotoSrcSet : void 0,
							alt: homepage.classroomPhoto ? homepage.classroomPhotoAlt : "T. Balu Mahendra sir",
							width: 1086,
							height: 1448,
							sizes: "(max-width: 700px) 100vw, 50vw"
						}) : /* @__PURE__ */ jsxs("div", {
							className: "photo-placeholder",
							children: [
								/* @__PURE__ */ jsx(BookOpen, {
									size: 50,
									strokeWidth: 1,
									"aria-hidden": "true"
								}),
								/* @__PURE__ */ jsx("span", { children: "A glimpse into the classroom" }),
								/* @__PURE__ */ jsx("p", { children: "Approved faculty and classroom photography will be shared here." })
							]
						}), /* @__PURE__ */ jsxs("div", {
							className: "spotlight-label",
							children: [/* @__PURE__ */ jsx("span", { children: "AT THE HEART OF SRI VIDYA" }), /* @__PURE__ */ jsxs("h3", { children: ["T. Balu Mahendra ", /* @__PURE__ */ jsx("small", { children: "sir" })] })]
						})]
					}), /* @__PURE__ */ jsxs("div", {
						className: "spotlight-copy",
						"data-reveal": true,
						children: [
							/* @__PURE__ */ jsx("span", {
								className: "eyebrow",
								children: "ABOUT SRI VIDYA CLASSES"
							}),
							/* @__PURE__ */ jsxs("h2", {
								id: "about-title",
								className: "home-heading",
								children: [
									"Learning that begins",
									/* @__PURE__ */ jsx("br", {}),
									"with understanding."
								]
							}),
							/* @__PURE__ */ jsx("p", { children: "Sri Vidya Classes brings school academics, competitive-exam preparation and subject mentorship into one learning journey, with T. Balu Mahendra sir at its heart." }),
							/* @__PURE__ */ jsx("p", { children: "Our focus is simple: make concepts meaningful, encourage questions and build a foundation for the next academic step." }),
							/* @__PURE__ */ jsxs("div", {
								className: "spotlight-principle",
								children: [/* @__PURE__ */ jsx("span", { "aria-hidden": "true" }), /* @__PURE__ */ jsxs("p", { children: [
									"Understand the idea.",
									/* @__PURE__ */ jsx("br", {}),
									/* @__PURE__ */ jsx("strong", { children: "Build the confidence to apply it." })
								] })]
							}),
							/* @__PURE__ */ jsxs("div", {
								className: "actions",
								children: [/* @__PURE__ */ jsxs(Button, {
									to: "/about",
									children: ["Discover Sri Vidya ", /* @__PURE__ */ jsx(ArrowRight, { size: 17 })]
								}), /* @__PURE__ */ jsxs(Link, {
									className: "text-link",
									to: "/faculty",
									children: ["Meet the faculty ", /* @__PURE__ */ jsx(ArrowRight, { size: 17 })]
								})]
							})
						]
					})]
				})
			}),
			/* @__PURE__ */ jsx("section", {
				className: "section why-section",
				"aria-labelledby": "why-title",
				children: /* @__PURE__ */ jsxs("div", {
					className: "container why-grid",
					"data-reveal-group": true,
					children: [/* @__PURE__ */ jsxs("div", {
						"data-reveal": true,
						children: [
							/* @__PURE__ */ jsx("span", {
								className: "eyebrow",
								children: "WHY CHOOSE SRI VIDYA"
							}),
							/* @__PURE__ */ jsxs("h2", {
								id: "why-title",
								className: "home-heading",
								children: [
									"The fundamentals",
									/* @__PURE__ */ jsx("br", {}),
									"make the difference."
								]
							}),
							/* @__PURE__ */ jsx("p", { children: "A learning focus built around understanding, consistency and the individual student." }),
							/* @__PURE__ */ jsxs("span", {
								className: "why-watermark",
								"aria-hidden": "true",
								children: [
									"Learn.",
									/* @__PURE__ */ jsx("br", {}),
									"Grow."
								]
							})
						]
					}), /* @__PURE__ */ jsx("div", {
						className: "strength-list",
						children: strengths.map(([title, copy], index) => /* @__PURE__ */ jsxs("article", {
							"data-reveal": true,
							children: [
								/* @__PURE__ */ jsxs("span", {
									className: "strength-number",
									children: ["0", index + 1]
								}),
								/* @__PURE__ */ jsxs("div", { children: [/* @__PURE__ */ jsx("h3", { children: title }), /* @__PURE__ */ jsx("p", { children: copy })] }),
								/* @__PURE__ */ jsx(Check, {
									size: 19,
									"aria-hidden": "true"
								})
							]
						}, title))
					})]
				})
			}),
			/* @__PURE__ */ jsx("section", {
				className: "section approach-section",
				"aria-labelledby": "approach-title",
				children: /* @__PURE__ */ jsxs("div", {
					className: "container",
					"data-reveal-group": true,
					children: [/* @__PURE__ */ jsxs("div", {
						className: "centered-heading",
						"data-reveal": true,
						children: [
							/* @__PURE__ */ jsx("span", {
								className: "eyebrow",
								children: "THE TEACHING APPROACH"
							}),
							/* @__PURE__ */ jsx("h2", {
								id: "approach-title",
								className: "home-heading",
								children: "A clear process. A step forward."
							}),
							/* @__PURE__ */ jsx("p", { children: "Understanding grows through a cycle of learning, application and reflection." })
						]
					}), /* @__PURE__ */ jsx("ol", {
						className: "approach-steps",
						children: steps.map(([title, copy, Icon], index) => /* @__PURE__ */ jsxs("li", {
							"data-reveal": true,
							children: [
								/* @__PURE__ */ jsxs("div", {
									className: "step-icon",
									children: [/* @__PURE__ */ jsx(Icon, {
										size: 28,
										strokeWidth: 1.5,
										"aria-hidden": "true"
									}), /* @__PURE__ */ jsxs("span", { children: ["0", index + 1] })]
								}),
								/* @__PURE__ */ jsx("h3", { children: title }),
								/* @__PURE__ */ jsx("p", { children: copy }),
								index < 3 && /* @__PURE__ */ jsx(ArrowRight, {
									className: "step-arrow",
									size: 20,
									"aria-hidden": "true"
								})
							]
						}, title))
					})]
				})
			}),
			/* @__PURE__ */ jsx("section", {
				className: "section results-section",
				"aria-labelledby": "results-title",
				children: /* @__PURE__ */ jsxs("div", {
					className: "container results-layout",
					"data-reveal-group": true,
					children: [/* @__PURE__ */ jsxs("div", {
						"data-reveal": true,
						children: [
							/* @__PURE__ */ jsx("span", {
								className: "eyebrow",
								children: "RESULTS & ACHIEVEMENTS"
							}),
							/* @__PURE__ */ jsxs("h2", {
								id: "results-title",
								className: "home-heading",
								children: [
									"Progress worth",
									/* @__PURE__ */ jsx("br", {}),
									"recognising."
								]
							}),
							/* @__PURE__ */ jsx("p", { children: "A space for verified academic achievements and approved student results." }),
							/* @__PURE__ */ jsxs(Link, {
								to: "/results",
								className: "text-link",
								children: ["Visit results ", /* @__PURE__ */ jsx(ArrowRight, { size: 17 })]
							})
						]
					}), /* @__PURE__ */ jsx("div", {
						className: "results-content",
						"data-reveal": true,
						children: homepage.results.length ? homepage.results.map((result) => /* @__PURE__ */ jsxs("article", { children: [
							/* @__PURE__ */ jsx(Trophy, {
								size: 25,
								"aria-hidden": "true"
							}),
							/* @__PURE__ */ jsx("h3", { children: result.title }),
							/* @__PURE__ */ jsx("p", { children: result.detail })
						] }, result.title)) : /* @__PURE__ */ jsxs("div", {
							className: "result-placeholder",
							children: [/* @__PURE__ */ jsx("span", {
								className: "result-seal",
								children: /* @__PURE__ */ jsx(Trophy, {
									size: 35,
									strokeWidth: 1.3,
									"aria-hidden": "true"
								})
							}), /* @__PURE__ */ jsxs("div", { children: [
								/* @__PURE__ */ jsx("h3", { children: "Every achievement deserves an accurate story." }),
								/* @__PURE__ */ jsx("p", { children: "Verified results will be shared once approved records are available. No student rankings or success-rate claims are published here." }),
								/* @__PURE__ */ jsx("span", {
									className: "status-label",
									children: "AWAITING APPROVED RECORDS"
								})
							] })]
						})
					})]
				})
			}),
			/* @__PURE__ */ jsx("section", {
				className: "section gallery-section",
				"aria-labelledby": "gallery-title",
				children: /* @__PURE__ */ jsxs("div", {
					className: "container",
					"data-reveal-group": true,
					children: [/* @__PURE__ */ jsxs("div", {
						className: "section-top",
						"data-reveal": true,
						children: [/* @__PURE__ */ jsxs("div", { children: [
							/* @__PURE__ */ jsx("span", {
								className: "eyebrow",
								children: "INSIDE SRI VIDYA"
							}),
							/* @__PURE__ */ jsx("h2", {
								id: "gallery-title",
								className: "home-heading",
								children: "Where learning comes to life."
							}),
							/* @__PURE__ */ jsx("p", { children: "A window into the classrooms and everyday learning at Sri Vidya Classes." })
						] }), /* @__PURE__ */ jsxs(Link, {
							to: "/gallery",
							className: "text-link",
							children: ["View gallery ", /* @__PURE__ */ jsx(ArrowRight, { size: 17 })]
						})]
					}), homepage.gallery.length ? /* @__PURE__ */ jsx("div", {
						className: "home-gallery",
						children: homepage.gallery.slice(0, 3).map((photo) => /* @__PURE__ */ jsxs("figure", {
							"data-reveal": true,
							children: [/* @__PURE__ */ jsx(ResponsiveImage, {
								src: photo.src,
								srcSet: photo.srcSet,
								sizes: "(max-width: 700px) 100vw, (max-width: 1000px) 50vw, 33vw",
								alt: photo.alt,
								width: photo.width,
								height: photo.height
							}), /* @__PURE__ */ jsx("figcaption", { children: photo.caption })]
						}, photo.src))
					}) : /* @__PURE__ */ jsxs("div", {
						className: "gallery-pending",
						"data-reveal": true,
						children: [
							/* @__PURE__ */ jsx("div", {
								className: "gallery-outline",
								"aria-hidden": "true",
								children: /* @__PURE__ */ jsx(Image, {
									size: 40,
									strokeWidth: 1
								})
							}),
							/* @__PURE__ */ jsxs("div", { children: [/* @__PURE__ */ jsx("h3", { children: "A real look inside. Coming soon." }), /* @__PURE__ */ jsx("p", { children: "Approved classroom and institute photographs will appear here. We’re keeping this space for the real Sri Vidya experience." })] }),
							/* @__PURE__ */ jsxs(Link, {
								className: "text-link",
								to: "/gallery",
								children: ["Gallery updates ", /* @__PURE__ */ jsx(ArrowRight, { size: 17 })]
							})
						]
					})]
				})
			}),
			homepage.testimonials.length > 0 && /* @__PURE__ */ jsx("section", {
				className: "section testimonials-section",
				children: /* @__PURE__ */ jsxs("div", {
					className: "container",
					"data-reveal-group": true,
					children: [/* @__PURE__ */ jsx(SectionHeading, {
						eyebrow: "VOICES OF SRI VIDYA",
						title: "In their own words."
					}), /* @__PURE__ */ jsx("div", {
						className: "home-testimonials",
						children: homepage.testimonials.map((item) => /* @__PURE__ */ jsxs("figure", {
							"data-reveal": true,
							children: [
								/* @__PURE__ */ jsx(MessageCircle, {
									size: 26,
									"aria-hidden": "true"
								}),
								/* @__PURE__ */ jsx("blockquote", { children: item.quote }),
								/* @__PURE__ */ jsxs("figcaption", { children: [/* @__PURE__ */ jsx("strong", { children: item.name }), /* @__PURE__ */ jsx("span", { children: item.role })] })
							]
						}, `${item.name}-${item.quote}`))
					})]
				})
			}),
			/* @__PURE__ */ jsx("section", {
				className: "admissions-strip",
				"aria-labelledby": "admissions-title",
				children: /* @__PURE__ */ jsxs("div", {
					className: "container",
					"data-reveal-group": true,
					children: [/* @__PURE__ */ jsxs("div", {
						"data-reveal": true,
						children: [
							/* @__PURE__ */ jsx("span", {
								className: "eyebrow",
								children: "LET’S FIND YOUR NEXT STEP"
							}),
							/* @__PURE__ */ jsx("h2", {
								id: "admissions-title",
								children: "Your learning journey starts with a conversation."
							}),
							/* @__PURE__ */ jsx("p", { children: "Tell us your class, your goals and what you would like to learn." })
						]
					}), /* @__PURE__ */ jsxs("div", {
						className: "admissions-actions",
						"data-reveal": true,
						children: [/* @__PURE__ */ jsxs(Button, {
							to: "/contact",
							children: ["Enquire for Admission ", /* @__PURE__ */ jsx(ArrowRight, { size: 17 })]
						}), /* @__PURE__ */ jsxs("a", {
							href: `tel:+91${institute.phone}`,
							children: [
								/* @__PURE__ */ jsx(Phone, {
									size: 16,
									"aria-hidden": "true"
								}),
								"Call ",
								institute.phone
							]
						})]
					})]
				})
			}),
			/* @__PURE__ */ jsx("section", {
				className: "section faq-section",
				"aria-labelledby": "faq-title",
				children: /* @__PURE__ */ jsxs("div", {
					className: "container faq-grid",
					"data-reveal-group": true,
					children: [/* @__PURE__ */ jsxs("div", {
						"data-reveal": true,
						children: [
							/* @__PURE__ */ jsx("span", {
								className: "eyebrow",
								children: "A LITTLE MORE CLARITY"
							}),
							/* @__PURE__ */ jsxs("h2", {
								id: "faq-title",
								className: "home-heading",
								children: [
									"Questions?",
									/* @__PURE__ */ jsx("br", {}),
									"Start here."
								]
							}),
							/* @__PURE__ */ jsx("p", { children: "Helpful information for students and parents planning their next step." }),
							/* @__PURE__ */ jsxs(Link, {
								className: "text-link",
								to: "/faqs",
								children: ["Visit FAQs ", /* @__PURE__ */ jsx(ArrowRight, { size: 17 })]
							})
						]
					}), /* @__PURE__ */ jsx("div", {
						className: "home-faqs",
						"data-reveal": true,
						children: faqs.map((faq) => /* @__PURE__ */ jsxs("details", { children: [/* @__PURE__ */ jsxs("summary", { children: [faq.question, /* @__PURE__ */ jsx("span", {
							className: "faq-plus",
							"aria-hidden": "true",
							children: "+"
						})] }), /* @__PURE__ */ jsx("p", { children: faq.answer })] }, faq.question))
					})]
				})
			}),
			/* @__PURE__ */ jsx("section", {
				className: "final-contact",
				children: /* @__PURE__ */ jsxs("div", {
					className: "container",
					"data-reveal-group": true,
					children: [/* @__PURE__ */ jsxs("div", {
						"data-reveal": true,
						children: [
							/* @__PURE__ */ jsx("span", {
								className: "eyebrow",
								children: "WE’RE HERE TO HELP"
							}),
							/* @__PURE__ */ jsx("h2", { children: "Let’s talk about what comes next." }),
							/* @__PURE__ */ jsx("p", { children: "Ask about programs, admissions and the right starting point." })
						]
					}), /* @__PURE__ */ jsxs(Button, {
						to: "/contact",
						children: ["Contact Sri Vidya ", /* @__PURE__ */ jsx(ArrowRight, { size: 18 })]
					})]
				})
			})
		]
	})] });
}
// src/pages/AcademicPages.tsx
function Breadcrumbs({ current, program = false }) {
	return /* @__PURE__ */ jsx("nav", {
		className: "academic-breadcrumb",
		"aria-label": "Breadcrumb",
		children: /* @__PURE__ */ jsxs("ol", { children: [
			/* @__PURE__ */ jsx("li", { children: /* @__PURE__ */ jsx(Link, {
				to: "/",
				children: "Home"
			}) }),
			program && /* @__PURE__ */ jsx("li", { children: /* @__PURE__ */ jsx(Link, {
				to: "/programs",
				children: "Programs"
			}) }),
			/* @__PURE__ */ jsx("li", {
				"aria-current": "page",
				children: current
			})
		] })
	});
}
function PageHero({ kind, eyebrow, title, children, image, alt, current }) {
	return /* @__PURE__ */ jsx("section", {
		className: `academic-hero academic-hero-${kind}`,
		children: /* @__PURE__ */ jsxs("div", {
			className: "container",
			children: [/* @__PURE__ */ jsx(Breadcrumbs, { current }), /* @__PURE__ */ jsxs("div", {
				className: "academic-hero-grid",
				children: [/* @__PURE__ */ jsxs("div", { children: [
					/* @__PURE__ */ jsx("span", {
						className: "eyebrow",
						children: eyebrow
					}),
					/* @__PURE__ */ jsx("h1", { children: title }),
					/* @__PURE__ */ jsx("p", { children })
				] }), image ? /* @__PURE__ */ jsx(ResponsiveImage, {
					src: image,
					alt: alt ?? "",
					width: 760,
					height: 540,
					loading: "eager"
				}) : /* @__PURE__ */ jsxs("div", {
					className: "academic-hero-art",
					"aria-hidden": "true",
					children: [kind === "faqs" ? /* @__PURE__ */ jsx("span", { children: "?" }) : kind === "programs" ? /* @__PURE__ */ jsx(GraduationCap, {
						size: 90,
						strokeWidth: 1
					}) : /* @__PURE__ */ jsx(BookOpen, {
						size: 90,
						strokeWidth: 1
					}), /* @__PURE__ */ jsx("span", {
						className: "academic-art-label",
						children: kind === "faqs" ? "ASK. UNDERSTAND. BEGIN." : "CURIOSITY. CLARITY. CONFIDENCE."
					})]
				})]
			})]
		})
	});
}
function EnquiryBand({ title = "Let’s talk about your next step." }) {
	return /* @__PURE__ */ jsx("section", {
		className: "academic-enquiry",
		children: /* @__PURE__ */ jsxs("div", {
			className: "container",
			children: [/* @__PURE__ */ jsxs("div", { children: [
				/* @__PURE__ */ jsx("span", {
					className: "eyebrow",
					children: "SRI VIDYA CLASSES"
				}),
				/* @__PURE__ */ jsx("h2", { children: title }),
				/* @__PURE__ */ jsx("p", { children: "Discuss your class, goals and questions with the institute." })
			] }), /* @__PURE__ */ jsxs("div", { children: [/* @__PURE__ */ jsxs(Button, {
				to: "/contact",
				children: ["Admission enquiry ", /* @__PURE__ */ jsx(ArrowRight, { size: 17 })]
			}), /* @__PURE__ */ jsxs("a", {
				href: `tel:+91${institute.phone}`,
				children: [/* @__PURE__ */ jsx(Phone, { size: 16 }), institute.phone]
			})] })]
		})
	});
}
function AboutPage() {
	return /* @__PURE__ */ jsxs("div", {
		className: "academic-page",
		children: [
			/* @__PURE__ */ jsx(PageHero, {
				kind: "about",
				current: "About",
				eyebrow: "THE SRI VIDYA STORY",
				title: "A foundation built on understanding.",
				image: academicImages.about,
				alt: "Approved view of Sri Vidya Classes",
				children: "Sri Vidya Classes connects school academics, competitive-exam preparation and Chemistry mentorship, with T. Balu Mahendra sir at its heart."
			}),
			/* @__PURE__ */ jsx("section", {
				className: "section",
				children: /* @__PURE__ */ jsxs("div", {
					className: "container academic-editorial",
					children: [/* @__PURE__ */ jsxs("div", { children: [/* @__PURE__ */ jsx("span", {
						className: "eyebrow",
						children: "OUR TEACHING PHILOSOPHY"
					}), /* @__PURE__ */ jsxs("h2", { children: [
						"Start with the question.",
						/* @__PURE__ */ jsx("br", {}),
						"Build towards clarity."
					] })] }), /* @__PURE__ */ jsxs("div", { children: [
						/* @__PURE__ */ jsx("p", { children: "Learning begins when an idea makes sense. The Sri Vidya approach places concept understanding before application, followed by practice, assessment and improvement." }),
						/* @__PURE__ */ jsx("p", { children: "From Classes 4–10 foundations to senior-secondary preparation and organic chemistry, the aim is to connect what a student learns with how they use it." }),
						/* @__PURE__ */ jsxs(Link, {
							className: "text-link",
							to: "/programs",
							children: ["Explore the learning pathways ", /* @__PURE__ */ jsx(ArrowRight, { size: 17 })]
						})
					] })]
				})
			}),
			/* @__PURE__ */ jsx("section", {
				className: "section academic-environment",
				children: /* @__PURE__ */ jsxs("div", {
					className: "container environment-grid",
					children: [academicImages.environment ? /* @__PURE__ */ jsx(ResponsiveImage, {
						src: academicImages.environment,
						alt: "Approved Sri Vidya classroom learning environment",
						width: 800,
						height: 650
					}) : /* @__PURE__ */ jsxs("div", {
						className: "academic-photo-pending",
						children: [
							/* @__PURE__ */ jsx(Image, {
								size: 40,
								strokeWidth: 1,
								"aria-hidden": "true"
							}),
							/* @__PURE__ */ jsx("h3", { children: "A real look at the learning space" }),
							/* @__PURE__ */ jsx("p", { children: "Approved classroom photographs will be added here." })
						]
					}), /* @__PURE__ */ jsxs("div", { children: [
						/* @__PURE__ */ jsx("span", {
							className: "eyebrow",
							children: "THE LEARNING ENVIRONMENT"
						}),
						/* @__PURE__ */ jsxs("h2", { children: [
							"Room for questions.",
							/* @__PURE__ */ jsx("br", {}),
							"Space to grow."
						] }),
						/* @__PURE__ */ jsx("p", { children: "A learning environment should help students ask questions, practise thoughtfully and revisit difficult ideas. These principles guide the academic focus of Sri Vidya Classes." }),
						/* @__PURE__ */ jsx("p", { children: "For current classroom arrangements and a possible visit, contact the institute before making plans." }),
						/* @__PURE__ */ jsxs(Button, {
							to: "/contact",
							secondary: true,
							children: ["Ask about a visit ", /* @__PURE__ */ jsx(ArrowRight, { size: 17 })]
						})
					] })]
				})
			}),
			/* @__PURE__ */ jsx("section", {
				className: "section",
				children: /* @__PURE__ */ jsxs("div", {
					className: "container",
					children: [
						/* @__PURE__ */ jsx("span", {
							className: "eyebrow",
							children: "THE VALUES THAT GUIDE US"
						}),
						/* @__PURE__ */ jsx("h2", { children: "Small principles. Lasting foundations." }),
						/* @__PURE__ */ jsx("div", {
							className: "academic-values",
							children: [
								["Clarity", "Seek understanding rather than memorising without meaning."],
								["Consistency", "Make practice and reflection part of the learning journey."],
								["Curiosity", "Encourage questions and connections between ideas."],
								["Care", "Recognise individual doubts and learning needs."]
							].map(([title, copy], i) => /* @__PURE__ */ jsxs("article", { children: [
								/* @__PURE__ */ jsxs("span", { children: ["0", i + 1] }),
								/* @__PURE__ */ jsx("h3", { children: title }),
								/* @__PURE__ */ jsx("p", { children: copy })
							] }, title))
						})
					]
				})
			}),
			/* @__PURE__ */ jsx(EnquiryBand, {})
		]
	});
}
function FacultyPage() {
	return /* @__PURE__ */ jsxs("div", {
		className: "academic-page",
		children: [
			/* @__PURE__ */ jsx("section", {
				className: "faculty-page-hero",
				children: /* @__PURE__ */ jsxs("div", {
					className: "container",
					children: [
						/* @__PURE__ */ jsx(Breadcrumbs, { current: "Faculty" }),
						/* @__PURE__ */ jsx("span", {
							className: "eyebrow",
							children: "THE PEOPLE BEHIND THE LEARNING"
						}),
						/* @__PURE__ */ jsx("h1", { children: "Meet the faculty." }),
						/* @__PURE__ */ jsx("p", { children: "Understanding starts with a thoughtful conversation." })
					]
				})
			}),
			faculty.map((person, index) => /* @__PURE__ */ jsx("section", {
				className: "section",
				children: /* @__PURE__ */ jsxs("div", {
					className: "container faculty-profile",
					children: [/* @__PURE__ */ jsxs("div", {
						className: "faculty-page-portrait",
						children: [person.portrait || index === 0 && institute.facultyPhoto ? /* @__PURE__ */ jsx(ResponsiveImage, {
							src: person.portrait || institute.facultyPhoto,
							srcSet: !person.portrait ? institute.facultyPhotoSrcSet : void 0,
							sizes: "(max-width: 700px) 90vw, 45vw",
							alt: `${person.name} sir`,
							width: 1086,
							height: 1448,
							loading: index === 0 ? "eager" : "lazy"
						}) : /* @__PURE__ */ jsxs("div", {
							className: "academic-photo-pending",
							children: [/* @__PURE__ */ jsx(BookOpen, {
								size: 50,
								strokeWidth: 1,
								"aria-hidden": "true"
							}), /* @__PURE__ */ jsxs("p", { children: [
								"Approved portrait of",
								/* @__PURE__ */ jsx("br", {}),
								person.name,
								" sir",
								/* @__PURE__ */ jsx("br", {}),
								"will be added here."
							] })]
						}), /* @__PURE__ */ jsx("span", {
							className: "faculty-photo-caption",
							children: "SRI VIDYA CLASSES · FACULTY"
						})]
					}), /* @__PURE__ */ jsxs("div", { children: [
						/* @__PURE__ */ jsx("span", {
							className: "eyebrow",
							children: person.focus
						}),
						/* @__PURE__ */ jsxs("h2", { children: [
							person.name,
							" ",
							/* @__PURE__ */ jsx("small", { children: "sir" })
						] }),
						/* @__PURE__ */ jsx("p", { children: person.introduction }),
						/* @__PURE__ */ jsxs("div", {
							className: "qualification-block",
							children: [/* @__PURE__ */ jsx("h3", { children: "Qualifications & profile" }), person.qualifications.length ? /* @__PURE__ */ jsx("ul", { children: person.qualifications.map((q) => /* @__PURE__ */ jsx("li", { children: q }, q)) }) : /* @__PURE__ */ jsx("p", { children: "Approved qualifications and a detailed professional profile are awaiting confirmation." })]
						}),
						/* @__PURE__ */ jsx("h3", { children: "Chemistry mentorship" }),
						/* @__PURE__ */ jsx("p", { children: "Explore subject-focused Organic Chemistry Mentorship and discuss your current understanding, questions and learning goals with the institute." }),
						/* @__PURE__ */ jsxs(Button, {
							to: "/programs/organic-chemistry-mentorship",
							secondary: true,
							children: ["Explore Organic Chemistry ", /* @__PURE__ */ jsx(ArrowRight, { size: 17 })]
						})
					] })]
				})
			}, person.id)),
			/* @__PURE__ */ jsx("section", {
				className: "section faculty-approach",
				children: /* @__PURE__ */ jsxs("div", {
					className: "container academic-editorial",
					children: [/* @__PURE__ */ jsxs("div", { children: [
						/* @__PURE__ */ jsx("span", {
							className: "eyebrow",
							children: "THE TEACHING APPROACH"
						}),
						/* @__PURE__ */ jsxs("h2", { children: [
							"From an idea",
							/* @__PURE__ */ jsx("br", {}),
							"to its application."
						] }),
						/* @__PURE__ */ jsx("p", { children: "Concept clarity, purposeful practice and reflection guide the learning process." })
					] }), /* @__PURE__ */ jsx("ol", { children: [
						"Understand the concept and ask why.",
						"Practise applying the idea.",
						"Assess understanding and identify gaps.",
						"Revisit and improve."
					].map((step, i) => /* @__PURE__ */ jsxs("li", { children: [/* @__PURE__ */ jsxs("span", { children: ["0", i + 1] }), step] }, step)) })]
				})
			}),
			/* @__PURE__ */ jsx(EnquiryBand, { title: "Have a question about Chemistry mentorship?" })
		]
	});
}
function ProgramsPage() {
	return /* @__PURE__ */ jsxs("div", {
		className: "academic-page",
		children: [
			/* @__PURE__ */ jsx(PageHero, {
				kind: "programs",
				current: "Programs",
				eyebrow: "CHOOSE YOUR LEARNING PATH",
				title: "For the stage you’re in. The goals ahead.",
				image: academicImages.programs,
				alt: "Approved academic learning photograph",
				children: "Explore school foundations, board and entrance preparation, and focused subject mentorship. Confirm availability and program specifics with the institute."
			}),
			/* @__PURE__ */ jsx("section", {
				className: "section",
				children: /* @__PURE__ */ jsx("div", {
					className: "container program-catalogue",
					children: programs.map((program, index) => /* @__PURE__ */ jsxs("article", {
						className: `catalogue-row catalogue-row-${index}`,
						children: [
							/* @__PURE__ */ jsxs("div", {
								className: "catalogue-index",
								children: [/* @__PURE__ */ jsxs("span", { children: ["0", index + 1] }), /* @__PURE__ */ jsx(GraduationCap, {
									size: 46,
									strokeWidth: 1,
									"aria-hidden": "true"
								})]
							}),
							/* @__PURE__ */ jsxs("div", { children: [
								/* @__PURE__ */ jsx("span", {
									className: "eyebrow",
									children: program.label
								}),
								/* @__PURE__ */ jsx("h2", { children: program.name }),
								/* @__PURE__ */ jsx("p", { children: program.description }),
								/* @__PURE__ */ jsx("span", {
									className: "catalogue-focus",
									children: program.focus
								})
							] }),
							/* @__PURE__ */ jsxs("div", {
								className: "catalogue-actions",
								children: [/* @__PURE__ */ jsxs(Button, {
									to: `/programs/${program.slug}`,
									children: ["View program ", /* @__PURE__ */ jsx(ArrowRight, { size: 17 })]
								}), /* @__PURE__ */ jsxs(Link, {
									to: "/contact",
									className: "text-link",
									children: ["Ask a question ", /* @__PURE__ */ jsx(ArrowRight, { size: 16 })]
								})]
							})
						]
					}, program.slug))
				})
			}),
			/* @__PURE__ */ jsx(EnquiryBand, { title: "Not sure where to begin?" })
		]
	});
}
function ProgramDetailPage() {
	const { slug } = useParams();
	const program = programs.find((item) => item.slug === slug);
	if (!program) return /* @__PURE__ */ jsx(NotFound, {});
	return /* @__PURE__ */ jsxs("div", {
		className: "academic-page",
		children: [
			/* @__PURE__ */ jsx("section", {
				className: "academic-program-hero",
				children: /* @__PURE__ */ jsxs("div", {
					className: "container",
					children: [
						/* @__PURE__ */ jsx(Breadcrumbs, {
							current: program.name,
							program: true
						}),
						/* @__PURE__ */ jsx("span", {
							className: "eyebrow",
							children: program.label
						}),
						/* @__PURE__ */ jsx("h1", { children: program.name.split("/").map((part, index) => /* @__PURE__ */ jsxs("span", { children: [index > 0 && /* @__PURE__ */ jsxs(Fragment, { children: [/* @__PURE__ */ jsx("span", { children: "/" }), /* @__PURE__ */ jsx("wbr", {})] }), part] }, part)) }),
						/* @__PURE__ */ jsx("p", { children: program.description }),
						/* @__PURE__ */ jsxs(Button, {
							to: "/contact",
							children: ["Enquire about this program ", /* @__PURE__ */ jsx(ArrowRight, { size: 17 })]
						})
					]
				})
			}),
			/* @__PURE__ */ jsx("section", {
				className: "section",
				children: /* @__PURE__ */ jsxs("div", {
					className: "container program-detail-grid",
					children: [/* @__PURE__ */ jsxs("div", {
						className: "program-detail-body",
						children: [
							/* @__PURE__ */ jsxs("section", {
								id: "overview",
								children: [
									/* @__PURE__ */ jsx("span", {
										className: "eyebrow",
										children: "THE BIG PICTURE"
									}),
									/* @__PURE__ */ jsx("h2", { children: "Program overview" }),
									/* @__PURE__ */ jsx("p", { children: program.overview })
								]
							}),
							/* @__PURE__ */ jsxs("section", {
								id: "subjects",
								children: [/* @__PURE__ */ jsx("h2", { children: "Subjects" }), program.subjects.length ? /* @__PURE__ */ jsx("ul", {
									className: "subject-tags",
									children: program.subjects.map((subject) => /* @__PURE__ */ jsx("li", { children: subject }, subject))
								}) : /* @__PURE__ */ jsx("p", { children: "The class-specific subject list is awaiting approval. Ask the institute about coverage for your class, board and chosen pathway." })]
							}),
							/* @__PURE__ */ jsxs("section", {
								id: "curriculum",
								children: [/* @__PURE__ */ jsx("h2", { children: "Curriculum" }), program.curriculum.length ? program.curriculum.map((item) => /* @__PURE__ */ jsxs("details", {
									className: "curriculum-detail",
									children: [/* @__PURE__ */ jsx("summary", { children: item.title }), /* @__PURE__ */ jsx("p", { children: item.description })]
								}, item.title)) : /* @__PURE__ */ jsxs("div", {
									className: "curriculum-note",
									children: [/* @__PURE__ */ jsx(BookOpen, {
										size: 26,
										"aria-hidden": "true"
									}), /* @__PURE__ */ jsxs("div", { children: [/* @__PURE__ */ jsx("h3", { children: "A confirmed outline, before you decide." }), /* @__PURE__ */ jsx("p", { children: "The detailed curriculum and topic sequence will be published after approval. Contact the institute for the syllabus relevant to you." })] })]
								})]
							}),
							/* @__PURE__ */ jsxs("section", {
								id: "methodology",
								children: [/* @__PURE__ */ jsx("h2", { children: "Teaching methodology" }), /* @__PURE__ */ jsx("ol", {
									className: "program-methodology",
									children: program.methodology.map((item, i) => /* @__PURE__ */ jsxs("li", { children: [/* @__PURE__ */ jsxs("span", { children: ["0", i + 1] }), item] }, item))
								})]
							}),
							/* @__PURE__ */ jsxs("section", {
								id: "eligibility",
								children: [/* @__PURE__ */ jsx("h2", { children: "Eligibility" }), /* @__PURE__ */ jsx("p", { children: program.eligibility })]
							})
						]
					}), /* @__PURE__ */ jsxs("aside", {
						className: "program-detail-aside",
						children: [
							/* @__PURE__ */ jsx("span", {
								className: "eyebrow",
								children: "AT A GLANCE"
							}),
							/* @__PURE__ */ jsx("h2", { children: program.label }),
							/* @__PURE__ */ jsx("p", { children: program.focus }),
							/* @__PURE__ */ jsx("nav", {
								"aria-label": "On this program page",
								children: [
									"Overview",
									"Subjects",
									"Curriculum",
									"Methodology",
									"Eligibility"
								].map((label) => /* @__PURE__ */ jsxs("a", {
									href: `#${label.toLowerCase()}`,
									children: [label, /* @__PURE__ */ jsx(ArrowRight, { size: 14 })]
								}, label))
							}),
							/* @__PURE__ */ jsx("p", { children: "Ask us about confirmed availability, fees and timings." }),
							/* @__PURE__ */ jsx(Button, {
								to: "/contact",
								children: "Admission enquiry"
							}),
							/* @__PURE__ */ jsxs("a", {
								className: "program-phone",
								href: `tel:+91${institute.phone}`,
								children: [/* @__PURE__ */ jsx(Phone, { size: 15 }), institute.phone]
							})
						]
					})]
				})
			}),
			/* @__PURE__ */ jsx("section", {
				className: "section related-programs",
				children: /* @__PURE__ */ jsxs("div", {
					className: "container",
					children: [
						/* @__PURE__ */ jsx("span", {
							className: "eyebrow",
							children: "KEEP EXPLORING"
						}),
						/* @__PURE__ */ jsx("h2", { children: "Other learning pathways" }),
						/* @__PURE__ */ jsx("div", { children: programs.filter((item) => item.slug !== slug).map((item) => /* @__PURE__ */ jsxs(Link, {
							to: `/programs/${item.slug}`,
							children: [/* @__PURE__ */ jsx("span", { children: item.name }), /* @__PURE__ */ jsx(ArrowRight, { size: 20 })]
						}, item.slug)) })
					]
				})
			}),
			/* @__PURE__ */ jsx(EnquiryBand, {})
		]
	});
}
function FaqsPage() {
	return /* @__PURE__ */ jsxs("div", {
		className: "academic-page",
		children: [
			/* @__PURE__ */ jsx(PageHero, {
				kind: "faqs",
				current: "FAQs",
				eyebrow: "HELPFUL ANSWERS",
				title: "A little clarity before your next step.",
				image: academicImages.faqs,
				alt: "Approved academic guidance photograph",
				children: "Find information about programs, admissions and learning at Sri Vidya Classes. For details that need a personal conversation, we’re a phone call away."
			}),
			/* @__PURE__ */ jsx("section", {
				className: "section",
				children: /* @__PURE__ */ jsxs("div", {
					className: "container academic-faq-layout",
					children: [/* @__PURE__ */ jsxs("aside", { children: [
						/* @__PURE__ */ jsx("h2", { children: "Find your question" }),
						/* @__PURE__ */ jsx("nav", {
							"aria-label": "FAQ categories",
							children: faqCategories.map((category) => /* @__PURE__ */ jsxs("a", {
								href: `#${category.id}`,
								children: [/* @__PURE__ */ jsx(Compass, {
									size: 16,
									"aria-hidden": "true"
								}), category.title]
							}, category.id))
						}),
						/* @__PURE__ */ jsxs(Link, {
							className: "text-link",
							to: "/contact",
							children: ["Still have a question? ", /* @__PURE__ */ jsx(ArrowRight, { size: 16 })]
						})
					] }), /* @__PURE__ */ jsx("div", { children: faqCategories.map((category) => /* @__PURE__ */ jsxs("section", {
						className: "academic-faq-category",
						id: category.id,
						children: [
							/* @__PURE__ */ jsx("span", {
								className: "eyebrow",
								children: "SRI VIDYA CLASSES"
							}),
							/* @__PURE__ */ jsx("h2", { children: category.title }),
							/* @__PURE__ */ jsx("div", {
								className: "home-faqs",
								children: category.items.map((item) => /* @__PURE__ */ jsxs("details", { children: [/* @__PURE__ */ jsxs("summary", { children: [item.question, /* @__PURE__ */ jsx("span", {
									className: "faq-plus",
									"aria-hidden": "true",
									children: "+"
								})] }), /* @__PURE__ */ jsx("p", { children: item.answer })] }, item.question))
							})
						]
					}, category.id)) })]
				})
			}),
			/* @__PURE__ */ jsx(EnquiryBand, { title: "Let’s answer your next question." })
		]
	});
}
// src/AppRoutes.tsx
var academicRoutes = {
	"/learning-hub": LearningHubPage,
	"/admissions": AdmissionsPage,
	"/contact": ContactPage,
	"/counselling": CounsellingPage,
	"/privacy": PrivacyPage,
	"/results": ResultsPage,
	"/gallery": GalleryPage,
	"/about": AboutPage,
	"/faculty": FacultyPage,
	"/programs": ProgramsPage,
	"/faqs": FaqsPage
};
function AppRoutes() {
	return /* @__PURE__ */ jsx(Routes, { children: /* @__PURE__ */ jsxs(Route, {
		caseSensitive: true,
		element: /* @__PURE__ */ jsx(Layout, {}),
		children: [
			/* @__PURE__ */ jsx(Route, {
				caseSensitive: true,
				index: true,
				element: /* @__PURE__ */ jsx(Home, {})
			}),
			Object.entries(academicRoutes).map(([path, Page]) => /* @__PURE__ */ jsx(Route, {
				caseSensitive: true,
				path,
				element: /* @__PURE__ */ jsx(Page, {})
			}, path)),
			Object.keys(pageInfo).filter((path) => !(path in academicRoutes)).map((path) => /* @__PURE__ */ jsx(Route, {
				caseSensitive: true,
				path,
				element: /* @__PURE__ */ jsx(ContentPage, {})
			}, path)),
			/* @__PURE__ */ jsx(Route, {
				caseSensitive: true,
				path: "/programs/:slug",
				element: /* @__PURE__ */ jsx(ProgramDetailPage, {})
			}),
			/* @__PURE__ */ jsx(Route, {
				caseSensitive: true,
				path: "/learning-hub/:slug",
				element: /* @__PURE__ */ jsx(ArticlePage, {})
			}),
			/* @__PURE__ */ jsx(Route, {
				caseSensitive: true,
				path: "*",
				element: /* @__PURE__ */ jsx(NotFound, {})
			})
		]
	}) });
}
// src/entry-server.tsx
function render(path) {
	return renderToString(/* @__PURE__ */ jsx(StaticRouter, {
		location: path,
		children: /* @__PURE__ */ jsx(AppRoutes, {})
	}));
}
export { getPageSeo, publicRoutes, render, renderSeoHead, seoPolicy };
