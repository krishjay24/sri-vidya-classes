﻿import { useEffect, useRef } from 'react'
import gsap from 'gsap'

export function useHomepageReveals() {
  const root = useRef<HTMLDivElement>(null)
  useEffect(() => {
    const media = gsap.matchMedia()
    media.add('(prefers-reduced-motion: no-preference)', () => {
      const observers: IntersectionObserver[] = []
      const context = gsap.context(() => {
        root.current?.querySelectorAll<HTMLElement>('[data-reveal-group]').forEach(group => {
          const targets = group.querySelectorAll('[data-reveal]')
          const observer = new IntersectionObserver(entries => {
            if (!entries.some(entry => entry.isIntersecting)) return
            context.add(() => {
              gsap.fromTo(targets, { y: 20, opacity: 0 }, { y: 0, opacity: 1, duration: .65, stagger: .09, ease: 'power2.out', clearProps: 'all' })
            })
            observer.disconnect()
          }, { threshold: .12 })
          observer.observe(group)
          observers.push(observer)
        })
      }, root)
      return () => { observers.forEach(observer => observer.disconnect()); context.revert() }
    })
    return () => media.revert()
  }, [])
  return root
}
